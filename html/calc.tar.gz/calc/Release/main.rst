                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : free open source ANSI-C Compiler
                              3 ; Version 3.1.4 #7658 (May  3 2012) (Linux)
                              4 ; This file was generated Mon May 21 12:35:53 2012
                              5 ;--------------------------------------------------------
                              6 	.module main
                              7 	.optsdcc -mmcs51 --model-small
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _main
                             13 	.globl _calc
                             14 	.globl _goToXY
                             15 	.globl _screen_left_shift
                             16 	.globl _init_lcd
                             17 	.globl _delay_ms
                             18 	.globl _KEY_D
                             19 	.globl _KEY_C
                             20 	.globl _KEY_B
                             21 	.globl _KEY_A
                             22 	.globl _BF
                             23 	.globl _E
                             24 	.globl _RW
                             25 	.globl _RS
                             26 	.globl _TF2
                             27 	.globl _EXF2
                             28 	.globl _RCLK
                             29 	.globl _TCLK
                             30 	.globl _EXEN2
                             31 	.globl _TR2
                             32 	.globl _C_T2
                             33 	.globl _CP_RL2
                             34 	.globl _T2CON_7
                             35 	.globl _T2CON_6
                             36 	.globl _T2CON_5
                             37 	.globl _T2CON_4
                             38 	.globl _T2CON_3
                             39 	.globl _T2CON_2
                             40 	.globl _T2CON_1
                             41 	.globl _T2CON_0
                             42 	.globl _PT2
                             43 	.globl _ET2
                             44 	.globl _CY
                             45 	.globl _AC
                             46 	.globl _F0
                             47 	.globl _RS1
                             48 	.globl _RS0
                             49 	.globl _OV
                             50 	.globl _F1
                             51 	.globl _P
                             52 	.globl _PS
                             53 	.globl _PT1
                             54 	.globl _PX1
                             55 	.globl _PT0
                             56 	.globl _PX0
                             57 	.globl _RD
                             58 	.globl _WR
                             59 	.globl _T1
                             60 	.globl _T0
                             61 	.globl _INT1
                             62 	.globl _INT0
                             63 	.globl _TXD
                             64 	.globl _RXD
                             65 	.globl _P3_7
                             66 	.globl _P3_6
                             67 	.globl _P3_5
                             68 	.globl _P3_4
                             69 	.globl _P3_3
                             70 	.globl _P3_2
                             71 	.globl _P3_1
                             72 	.globl _P3_0
                             73 	.globl _EA
                             74 	.globl _ES
                             75 	.globl _ET1
                             76 	.globl _EX1
                             77 	.globl _ET0
                             78 	.globl _EX0
                             79 	.globl _P2_7
                             80 	.globl _P2_6
                             81 	.globl _P2_5
                             82 	.globl _P2_4
                             83 	.globl _P2_3
                             84 	.globl _P2_2
                             85 	.globl _P2_1
                             86 	.globl _P2_0
                             87 	.globl _SM0
                             88 	.globl _SM1
                             89 	.globl _SM2
                             90 	.globl _REN
                             91 	.globl _TB8
                             92 	.globl _RB8
                             93 	.globl _TI
                             94 	.globl _RI
                             95 	.globl _P1_7
                             96 	.globl _P1_6
                             97 	.globl _P1_5
                             98 	.globl _P1_4
                             99 	.globl _P1_3
                            100 	.globl _P1_2
                            101 	.globl _P1_1
                            102 	.globl _P1_0
                            103 	.globl _TF1
                            104 	.globl _TR1
                            105 	.globl _TF0
                            106 	.globl _TR0
                            107 	.globl _IE1
                            108 	.globl _IT1
                            109 	.globl _IE0
                            110 	.globl _IT0
                            111 	.globl _P0_7
                            112 	.globl _P0_6
                            113 	.globl _P0_5
                            114 	.globl _P0_4
                            115 	.globl _P0_3
                            116 	.globl _P0_2
                            117 	.globl _P0_1
                            118 	.globl _P0_0
                            119 	.globl _TH2
                            120 	.globl _TL2
                            121 	.globl _RCAP2H
                            122 	.globl _RCAP2L
                            123 	.globl _T2CON
                            124 	.globl _B
                            125 	.globl _ACC
                            126 	.globl _PSW
                            127 	.globl _IP
                            128 	.globl _P3
                            129 	.globl _IE
                            130 	.globl _P2
                            131 	.globl _SBUF
                            132 	.globl _SCON
                            133 	.globl _P1
                            134 	.globl _TH1
                            135 	.globl _TH0
                            136 	.globl _TL1
                            137 	.globl _TL0
                            138 	.globl _TMOD
                            139 	.globl _TCON
                            140 	.globl _PCON
                            141 	.globl _DPH
                            142 	.globl _DPL
                            143 	.globl _SP
                            144 	.globl _P0
                            145 ;--------------------------------------------------------
                            146 ; special function registers
                            147 ;--------------------------------------------------------
                            148 	.area RSEG    (ABS,DATA)
   0000                     149 	.org 0x0000
                    0080    150 _P0	=	0x0080
                    0081    151 _SP	=	0x0081
                    0082    152 _DPL	=	0x0082
                    0083    153 _DPH	=	0x0083
                    0087    154 _PCON	=	0x0087
                    0088    155 _TCON	=	0x0088
                    0089    156 _TMOD	=	0x0089
                    008A    157 _TL0	=	0x008a
                    008B    158 _TL1	=	0x008b
                    008C    159 _TH0	=	0x008c
                    008D    160 _TH1	=	0x008d
                    0090    161 _P1	=	0x0090
                    0098    162 _SCON	=	0x0098
                    0099    163 _SBUF	=	0x0099
                    00A0    164 _P2	=	0x00a0
                    00A8    165 _IE	=	0x00a8
                    00B0    166 _P3	=	0x00b0
                    00B8    167 _IP	=	0x00b8
                    00D0    168 _PSW	=	0x00d0
                    00E0    169 _ACC	=	0x00e0
                    00F0    170 _B	=	0x00f0
                    00C8    171 _T2CON	=	0x00c8
                    00CA    172 _RCAP2L	=	0x00ca
                    00CB    173 _RCAP2H	=	0x00cb
                    00CC    174 _TL2	=	0x00cc
                    00CD    175 _TH2	=	0x00cd
                            176 ;--------------------------------------------------------
                            177 ; special function bits
                            178 ;--------------------------------------------------------
                            179 	.area RSEG    (ABS,DATA)
   0000                     180 	.org 0x0000
                    0080    181 _P0_0	=	0x0080
                    0081    182 _P0_1	=	0x0081
                    0082    183 _P0_2	=	0x0082
                    0083    184 _P0_3	=	0x0083
                    0084    185 _P0_4	=	0x0084
                    0085    186 _P0_5	=	0x0085
                    0086    187 _P0_6	=	0x0086
                    0087    188 _P0_7	=	0x0087
                    0088    189 _IT0	=	0x0088
                    0089    190 _IE0	=	0x0089
                    008A    191 _IT1	=	0x008a
                    008B    192 _IE1	=	0x008b
                    008C    193 _TR0	=	0x008c
                    008D    194 _TF0	=	0x008d
                    008E    195 _TR1	=	0x008e
                    008F    196 _TF1	=	0x008f
                    0090    197 _P1_0	=	0x0090
                    0091    198 _P1_1	=	0x0091
                    0092    199 _P1_2	=	0x0092
                    0093    200 _P1_3	=	0x0093
                    0094    201 _P1_4	=	0x0094
                    0095    202 _P1_5	=	0x0095
                    0096    203 _P1_6	=	0x0096
                    0097    204 _P1_7	=	0x0097
                    0098    205 _RI	=	0x0098
                    0099    206 _TI	=	0x0099
                    009A    207 _RB8	=	0x009a
                    009B    208 _TB8	=	0x009b
                    009C    209 _REN	=	0x009c
                    009D    210 _SM2	=	0x009d
                    009E    211 _SM1	=	0x009e
                    009F    212 _SM0	=	0x009f
                    00A0    213 _P2_0	=	0x00a0
                    00A1    214 _P2_1	=	0x00a1
                    00A2    215 _P2_2	=	0x00a2
                    00A3    216 _P2_3	=	0x00a3
                    00A4    217 _P2_4	=	0x00a4
                    00A5    218 _P2_5	=	0x00a5
                    00A6    219 _P2_6	=	0x00a6
                    00A7    220 _P2_7	=	0x00a7
                    00A8    221 _EX0	=	0x00a8
                    00A9    222 _ET0	=	0x00a9
                    00AA    223 _EX1	=	0x00aa
                    00AB    224 _ET1	=	0x00ab
                    00AC    225 _ES	=	0x00ac
                    00AF    226 _EA	=	0x00af
                    00B0    227 _P3_0	=	0x00b0
                    00B1    228 _P3_1	=	0x00b1
                    00B2    229 _P3_2	=	0x00b2
                    00B3    230 _P3_3	=	0x00b3
                    00B4    231 _P3_4	=	0x00b4
                    00B5    232 _P3_5	=	0x00b5
                    00B6    233 _P3_6	=	0x00b6
                    00B7    234 _P3_7	=	0x00b7
                    00B0    235 _RXD	=	0x00b0
                    00B1    236 _TXD	=	0x00b1
                    00B2    237 _INT0	=	0x00b2
                    00B3    238 _INT1	=	0x00b3
                    00B4    239 _T0	=	0x00b4
                    00B5    240 _T1	=	0x00b5
                    00B6    241 _WR	=	0x00b6
                    00B7    242 _RD	=	0x00b7
                    00B8    243 _PX0	=	0x00b8
                    00B9    244 _PT0	=	0x00b9
                    00BA    245 _PX1	=	0x00ba
                    00BB    246 _PT1	=	0x00bb
                    00BC    247 _PS	=	0x00bc
                    00D0    248 _P	=	0x00d0
                    00D1    249 _F1	=	0x00d1
                    00D2    250 _OV	=	0x00d2
                    00D3    251 _RS0	=	0x00d3
                    00D4    252 _RS1	=	0x00d4
                    00D5    253 _F0	=	0x00d5
                    00D6    254 _AC	=	0x00d6
                    00D7    255 _CY	=	0x00d7
                    00AD    256 _ET2	=	0x00ad
                    00BD    257 _PT2	=	0x00bd
                    00C8    258 _T2CON_0	=	0x00c8
                    00C9    259 _T2CON_1	=	0x00c9
                    00CA    260 _T2CON_2	=	0x00ca
                    00CB    261 _T2CON_3	=	0x00cb
                    00CC    262 _T2CON_4	=	0x00cc
                    00CD    263 _T2CON_5	=	0x00cd
                    00CE    264 _T2CON_6	=	0x00ce
                    00CF    265 _T2CON_7	=	0x00cf
                    00C8    266 _CP_RL2	=	0x00c8
                    00C9    267 _C_T2	=	0x00c9
                    00CA    268 _TR2	=	0x00ca
                    00CB    269 _EXEN2	=	0x00cb
                    00CC    270 _TCLK	=	0x00cc
                    00CD    271 _RCLK	=	0x00cd
                    00CE    272 _EXF2	=	0x00ce
                    00CF    273 _TF2	=	0x00cf
                    0090    274 _RS	=	0x0090
                    0091    275 _RW	=	0x0091
                    0092    276 _E	=	0x0092
                    0087    277 _BF	=	0x0087
                    0093    278 _KEY_A	=	0x0093
                    0094    279 _KEY_B	=	0x0094
                    0095    280 _KEY_C	=	0x0095
                    0096    281 _KEY_D	=	0x0096
                            282 ;--------------------------------------------------------
                            283 ; overlayable register banks
                            284 ;--------------------------------------------------------
                            285 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     286 	.ds 8
                            287 ;--------------------------------------------------------
                            288 ; internal ram data
                            289 ;--------------------------------------------------------
                            290 	.area DSEG    (DATA)
                            291 ;--------------------------------------------------------
                            292 ; overlayable items in internal ram 
                            293 ;--------------------------------------------------------
                            294 ;--------------------------------------------------------
                            295 ; Stack segment in internal ram 
                            296 ;--------------------------------------------------------
                            297 	.area	SSEG	(DATA)
   003A                     298 __start__stack:
   003A                     299 	.ds	1
                            300 
                            301 ;--------------------------------------------------------
                            302 ; indirectly addressable internal ram data
                            303 ;--------------------------------------------------------
                            304 	.area ISEG    (DATA)
                            305 ;--------------------------------------------------------
                            306 ; absolute internal ram data
                            307 ;--------------------------------------------------------
                            308 	.area IABS    (ABS,DATA)
                            309 	.area IABS    (ABS,DATA)
                            310 ;--------------------------------------------------------
                            311 ; bit data
                            312 ;--------------------------------------------------------
                            313 	.area BSEG    (BIT)
                            314 ;--------------------------------------------------------
                            315 ; paged external ram data
                            316 ;--------------------------------------------------------
                            317 	.area PSEG    (PAG,XDATA)
                            318 ;--------------------------------------------------------
                            319 ; external ram data
                            320 ;--------------------------------------------------------
                            321 	.area XSEG    (XDATA)
                            322 ;--------------------------------------------------------
                            323 ; absolute external ram data
                            324 ;--------------------------------------------------------
                            325 	.area XABS    (ABS,XDATA)
                            326 ;--------------------------------------------------------
                            327 ; external initialized ram data
                            328 ;--------------------------------------------------------
                            329 	.area XISEG   (XDATA)
                            330 	.area HOME    (CODE)
                            331 	.area GSINIT0 (CODE)
                            332 	.area GSINIT1 (CODE)
                            333 	.area GSINIT2 (CODE)
                            334 	.area GSINIT3 (CODE)
                            335 	.area GSINIT4 (CODE)
                            336 	.area GSINIT5 (CODE)
                            337 	.area GSINIT  (CODE)
                            338 	.area GSFINAL (CODE)
                            339 	.area CSEG    (CODE)
                            340 ;--------------------------------------------------------
                            341 ; interrupt vector 
                            342 ;--------------------------------------------------------
                            343 	.area HOME    (CODE)
   0000                     344 __interrupt_vect:
   0000 02 00 08            345 	ljmp	__sdcc_gsinit_startup
                            346 ;--------------------------------------------------------
                            347 ; global & static initialisations
                            348 ;--------------------------------------------------------
                            349 	.area HOME    (CODE)
                            350 	.area GSINIT  (CODE)
                            351 	.area GSFINAL (CODE)
                            352 	.area GSINIT  (CODE)
                            353 	.globl __sdcc_gsinit_startup
                            354 	.globl __sdcc_program_startup
                            355 	.globl __start__stack
                            356 	.globl __mcs51_genXINIT
                            357 	.globl __mcs51_genXRAMCLEAR
                            358 	.globl __mcs51_genRAMCLEAR
                            359 	.area GSFINAL (CODE)
   0079 02 00 03            360 	ljmp	__sdcc_program_startup
                            361 ;--------------------------------------------------------
                            362 ; Home
                            363 ;--------------------------------------------------------
                            364 	.area HOME    (CODE)
                            365 	.area HOME    (CODE)
   0003                     366 __sdcc_program_startup:
   0003 12 0A F1            367 	lcall	_main
                            368 ;	return from main will lock up
   0006 80 FE               369 	sjmp .
                            370 ;--------------------------------------------------------
                            371 ; code
                            372 ;--------------------------------------------------------
                            373 	.area CSEG    (CODE)
                            374 ;------------------------------------------------------------
                            375 ;Allocation info for local variables in function 'main'
                            376 ;------------------------------------------------------------
                            377 ;	../main.c:18: void main(void)
                            378 ;	-----------------------------------------
                            379 ;	 function main
                            380 ;	-----------------------------------------
   0AF1                     381 _main:
                    0007    382 	ar7 = 0x07
                    0006    383 	ar6 = 0x06
                    0005    384 	ar5 = 0x05
                    0004    385 	ar4 = 0x04
                    0003    386 	ar3 = 0x03
                    0002    387 	ar2 = 0x02
                    0001    388 	ar1 = 0x01
                    0000    389 	ar0 = 0x00
                            390 ;	../main.c:20: init_lcd();
   0AF1 12 09 B4            391 	lcall	_init_lcd
                            392 ;	../main.c:21: delay_ms(10);
   0AF4 75 82 0A            393 	mov	dpl,#0x0A
   0AF7 12 07 27            394 	lcall	_delay_ms
                            395 ;	../main.c:22: screen_left_shift();
   0AFA 12 0A C1            396 	lcall	_screen_left_shift
                            397 ;	../main.c:23: goToXY(1,1);
   0AFD 75 08 01            398 	mov	_goToXY_PARM_2,#0x01
   0B00 75 82 01            399 	mov	dpl,#0x01
   0B03 12 0A 99            400 	lcall	_goToXY
                            401 ;	../main.c:24: while(1)
   0B06                     402 00102$:
                            403 ;	../main.c:26: calc();
   0B06 12 00 A3            404 	lcall	_calc
   0B09 80 FB               405 	sjmp	00102$
                            406 	.area CSEG    (CODE)
                            407 	.area CONST   (CODE)
                            408 	.area XINIT   (CODE)
                            409 	.area CABS    (ABS,CODE)
