                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : free open source ANSI-C Compiler
                              3 ; Version 3.1.4 #7658 (May  3 2012) (Linux)
                              4 ; This file was generated Mon May 21 12:35:53 2012
                              5 ;--------------------------------------------------------
                              6 	.module key
                              7 	.optsdcc -mmcs51 --model-small
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _delay_ms
                             13 	.globl _KEY_D
                             14 	.globl _KEY_C
                             15 	.globl _KEY_B
                             16 	.globl _KEY_A
                             17 	.globl _TF2
                             18 	.globl _EXF2
                             19 	.globl _RCLK
                             20 	.globl _TCLK
                             21 	.globl _EXEN2
                             22 	.globl _TR2
                             23 	.globl _C_T2
                             24 	.globl _CP_RL2
                             25 	.globl _T2CON_7
                             26 	.globl _T2CON_6
                             27 	.globl _T2CON_5
                             28 	.globl _T2CON_4
                             29 	.globl _T2CON_3
                             30 	.globl _T2CON_2
                             31 	.globl _T2CON_1
                             32 	.globl _T2CON_0
                             33 	.globl _PT2
                             34 	.globl _ET2
                             35 	.globl _CY
                             36 	.globl _AC
                             37 	.globl _F0
                             38 	.globl _RS1
                             39 	.globl _RS0
                             40 	.globl _OV
                             41 	.globl _F1
                             42 	.globl _P
                             43 	.globl _PS
                             44 	.globl _PT1
                             45 	.globl _PX1
                             46 	.globl _PT0
                             47 	.globl _PX0
                             48 	.globl _RD
                             49 	.globl _WR
                             50 	.globl _T1
                             51 	.globl _T0
                             52 	.globl _INT1
                             53 	.globl _INT0
                             54 	.globl _TXD
                             55 	.globl _RXD
                             56 	.globl _P3_7
                             57 	.globl _P3_6
                             58 	.globl _P3_5
                             59 	.globl _P3_4
                             60 	.globl _P3_3
                             61 	.globl _P3_2
                             62 	.globl _P3_1
                             63 	.globl _P3_0
                             64 	.globl _EA
                             65 	.globl _ES
                             66 	.globl _ET1
                             67 	.globl _EX1
                             68 	.globl _ET0
                             69 	.globl _EX0
                             70 	.globl _P2_7
                             71 	.globl _P2_6
                             72 	.globl _P2_5
                             73 	.globl _P2_4
                             74 	.globl _P2_3
                             75 	.globl _P2_2
                             76 	.globl _P2_1
                             77 	.globl _P2_0
                             78 	.globl _SM0
                             79 	.globl _SM1
                             80 	.globl _SM2
                             81 	.globl _REN
                             82 	.globl _TB8
                             83 	.globl _RB8
                             84 	.globl _TI
                             85 	.globl _RI
                             86 	.globl _P1_7
                             87 	.globl _P1_6
                             88 	.globl _P1_5
                             89 	.globl _P1_4
                             90 	.globl _P1_3
                             91 	.globl _P1_2
                             92 	.globl _P1_1
                             93 	.globl _P1_0
                             94 	.globl _TF1
                             95 	.globl _TR1
                             96 	.globl _TF0
                             97 	.globl _TR0
                             98 	.globl _IE1
                             99 	.globl _IT1
                            100 	.globl _IE0
                            101 	.globl _IT0
                            102 	.globl _P0_7
                            103 	.globl _P0_6
                            104 	.globl _P0_5
                            105 	.globl _P0_4
                            106 	.globl _P0_3
                            107 	.globl _P0_2
                            108 	.globl _P0_1
                            109 	.globl _P0_0
                            110 	.globl _TH2
                            111 	.globl _TL2
                            112 	.globl _RCAP2H
                            113 	.globl _RCAP2L
                            114 	.globl _T2CON
                            115 	.globl _B
                            116 	.globl _ACC
                            117 	.globl _PSW
                            118 	.globl _IP
                            119 	.globl _P3
                            120 	.globl _IE
                            121 	.globl _P2
                            122 	.globl _SBUF
                            123 	.globl _SCON
                            124 	.globl _P1
                            125 	.globl _TH1
                            126 	.globl _TH0
                            127 	.globl _TL1
                            128 	.globl _TL0
                            129 	.globl _TMOD
                            130 	.globl _TCON
                            131 	.globl _PCON
                            132 	.globl _DPH
                            133 	.globl _DPL
                            134 	.globl _SP
                            135 	.globl _P0
                            136 	.globl _scanKey
                            137 	.globl _scanKeyToInt
                            138 ;--------------------------------------------------------
                            139 ; special function registers
                            140 ;--------------------------------------------------------
                            141 	.area RSEG    (ABS,DATA)
   0000                     142 	.org 0x0000
                    0080    143 _P0	=	0x0080
                    0081    144 _SP	=	0x0081
                    0082    145 _DPL	=	0x0082
                    0083    146 _DPH	=	0x0083
                    0087    147 _PCON	=	0x0087
                    0088    148 _TCON	=	0x0088
                    0089    149 _TMOD	=	0x0089
                    008A    150 _TL0	=	0x008a
                    008B    151 _TL1	=	0x008b
                    008C    152 _TH0	=	0x008c
                    008D    153 _TH1	=	0x008d
                    0090    154 _P1	=	0x0090
                    0098    155 _SCON	=	0x0098
                    0099    156 _SBUF	=	0x0099
                    00A0    157 _P2	=	0x00a0
                    00A8    158 _IE	=	0x00a8
                    00B0    159 _P3	=	0x00b0
                    00B8    160 _IP	=	0x00b8
                    00D0    161 _PSW	=	0x00d0
                    00E0    162 _ACC	=	0x00e0
                    00F0    163 _B	=	0x00f0
                    00C8    164 _T2CON	=	0x00c8
                    00CA    165 _RCAP2L	=	0x00ca
                    00CB    166 _RCAP2H	=	0x00cb
                    00CC    167 _TL2	=	0x00cc
                    00CD    168 _TH2	=	0x00cd
                            169 ;--------------------------------------------------------
                            170 ; special function bits
                            171 ;--------------------------------------------------------
                            172 	.area RSEG    (ABS,DATA)
   0000                     173 	.org 0x0000
                    0080    174 _P0_0	=	0x0080
                    0081    175 _P0_1	=	0x0081
                    0082    176 _P0_2	=	0x0082
                    0083    177 _P0_3	=	0x0083
                    0084    178 _P0_4	=	0x0084
                    0085    179 _P0_5	=	0x0085
                    0086    180 _P0_6	=	0x0086
                    0087    181 _P0_7	=	0x0087
                    0088    182 _IT0	=	0x0088
                    0089    183 _IE0	=	0x0089
                    008A    184 _IT1	=	0x008a
                    008B    185 _IE1	=	0x008b
                    008C    186 _TR0	=	0x008c
                    008D    187 _TF0	=	0x008d
                    008E    188 _TR1	=	0x008e
                    008F    189 _TF1	=	0x008f
                    0090    190 _P1_0	=	0x0090
                    0091    191 _P1_1	=	0x0091
                    0092    192 _P1_2	=	0x0092
                    0093    193 _P1_3	=	0x0093
                    0094    194 _P1_4	=	0x0094
                    0095    195 _P1_5	=	0x0095
                    0096    196 _P1_6	=	0x0096
                    0097    197 _P1_7	=	0x0097
                    0098    198 _RI	=	0x0098
                    0099    199 _TI	=	0x0099
                    009A    200 _RB8	=	0x009a
                    009B    201 _TB8	=	0x009b
                    009C    202 _REN	=	0x009c
                    009D    203 _SM2	=	0x009d
                    009E    204 _SM1	=	0x009e
                    009F    205 _SM0	=	0x009f
                    00A0    206 _P2_0	=	0x00a0
                    00A1    207 _P2_1	=	0x00a1
                    00A2    208 _P2_2	=	0x00a2
                    00A3    209 _P2_3	=	0x00a3
                    00A4    210 _P2_4	=	0x00a4
                    00A5    211 _P2_5	=	0x00a5
                    00A6    212 _P2_6	=	0x00a6
                    00A7    213 _P2_7	=	0x00a7
                    00A8    214 _EX0	=	0x00a8
                    00A9    215 _ET0	=	0x00a9
                    00AA    216 _EX1	=	0x00aa
                    00AB    217 _ET1	=	0x00ab
                    00AC    218 _ES	=	0x00ac
                    00AF    219 _EA	=	0x00af
                    00B0    220 _P3_0	=	0x00b0
                    00B1    221 _P3_1	=	0x00b1
                    00B2    222 _P3_2	=	0x00b2
                    00B3    223 _P3_3	=	0x00b3
                    00B4    224 _P3_4	=	0x00b4
                    00B5    225 _P3_5	=	0x00b5
                    00B6    226 _P3_6	=	0x00b6
                    00B7    227 _P3_7	=	0x00b7
                    00B0    228 _RXD	=	0x00b0
                    00B1    229 _TXD	=	0x00b1
                    00B2    230 _INT0	=	0x00b2
                    00B3    231 _INT1	=	0x00b3
                    00B4    232 _T0	=	0x00b4
                    00B5    233 _T1	=	0x00b5
                    00B6    234 _WR	=	0x00b6
                    00B7    235 _RD	=	0x00b7
                    00B8    236 _PX0	=	0x00b8
                    00B9    237 _PT0	=	0x00b9
                    00BA    238 _PX1	=	0x00ba
                    00BB    239 _PT1	=	0x00bb
                    00BC    240 _PS	=	0x00bc
                    00D0    241 _P	=	0x00d0
                    00D1    242 _F1	=	0x00d1
                    00D2    243 _OV	=	0x00d2
                    00D3    244 _RS0	=	0x00d3
                    00D4    245 _RS1	=	0x00d4
                    00D5    246 _F0	=	0x00d5
                    00D6    247 _AC	=	0x00d6
                    00D7    248 _CY	=	0x00d7
                    00AD    249 _ET2	=	0x00ad
                    00BD    250 _PT2	=	0x00bd
                    00C8    251 _T2CON_0	=	0x00c8
                    00C9    252 _T2CON_1	=	0x00c9
                    00CA    253 _T2CON_2	=	0x00ca
                    00CB    254 _T2CON_3	=	0x00cb
                    00CC    255 _T2CON_4	=	0x00cc
                    00CD    256 _T2CON_5	=	0x00cd
                    00CE    257 _T2CON_6	=	0x00ce
                    00CF    258 _T2CON_7	=	0x00cf
                    00C8    259 _CP_RL2	=	0x00c8
                    00C9    260 _C_T2	=	0x00c9
                    00CA    261 _TR2	=	0x00ca
                    00CB    262 _EXEN2	=	0x00cb
                    00CC    263 _TCLK	=	0x00cc
                    00CD    264 _RCLK	=	0x00cd
                    00CE    265 _EXF2	=	0x00ce
                    00CF    266 _TF2	=	0x00cf
                    0093    267 _KEY_A	=	0x0093
                    0094    268 _KEY_B	=	0x0094
                    0095    269 _KEY_C	=	0x0095
                    0096    270 _KEY_D	=	0x0096
                            271 ;--------------------------------------------------------
                            272 ; overlayable register banks
                            273 ;--------------------------------------------------------
                            274 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     275 	.ds 8
                            276 ;--------------------------------------------------------
                            277 ; internal ram data
                            278 ;--------------------------------------------------------
                            279 	.area DSEG    (DATA)
                            280 ;--------------------------------------------------------
                            281 ; overlayable items in internal ram 
                            282 ;--------------------------------------------------------
                            283 ;--------------------------------------------------------
                            284 ; indirectly addressable internal ram data
                            285 ;--------------------------------------------------------
                            286 	.area ISEG    (DATA)
                            287 ;--------------------------------------------------------
                            288 ; absolute internal ram data
                            289 ;--------------------------------------------------------
                            290 	.area IABS    (ABS,DATA)
                            291 	.area IABS    (ABS,DATA)
                            292 ;--------------------------------------------------------
                            293 ; bit data
                            294 ;--------------------------------------------------------
                            295 	.area BSEG    (BIT)
                            296 ;--------------------------------------------------------
                            297 ; paged external ram data
                            298 ;--------------------------------------------------------
                            299 	.area PSEG    (PAG,XDATA)
                            300 ;--------------------------------------------------------
                            301 ; external ram data
                            302 ;--------------------------------------------------------
                            303 	.area XSEG    (XDATA)
                            304 ;--------------------------------------------------------
                            305 ; absolute external ram data
                            306 ;--------------------------------------------------------
                            307 	.area XABS    (ABS,XDATA)
                            308 ;--------------------------------------------------------
                            309 ; external initialized ram data
                            310 ;--------------------------------------------------------
                            311 	.area XISEG   (XDATA)
                            312 	.area HOME    (CODE)
                            313 	.area GSINIT0 (CODE)
                            314 	.area GSINIT1 (CODE)
                            315 	.area GSINIT2 (CODE)
                            316 	.area GSINIT3 (CODE)
                            317 	.area GSINIT4 (CODE)
                            318 	.area GSINIT5 (CODE)
                            319 	.area GSINIT  (CODE)
                            320 	.area GSFINAL (CODE)
                            321 	.area CSEG    (CODE)
                            322 ;--------------------------------------------------------
                            323 ; global & static initialisations
                            324 ;--------------------------------------------------------
                            325 	.area HOME    (CODE)
                            326 	.area GSINIT  (CODE)
                            327 	.area GSFINAL (CODE)
                            328 	.area GSINIT  (CODE)
                            329 ;--------------------------------------------------------
                            330 ; Home
                            331 ;--------------------------------------------------------
                            332 	.area HOME    (CODE)
                            333 	.area HOME    (CODE)
                            334 ;--------------------------------------------------------
                            335 ; code
                            336 ;--------------------------------------------------------
                            337 	.area CSEG    (CODE)
                            338 ;------------------------------------------------------------
                            339 ;Allocation info for local variables in function 'scanKey'
                            340 ;------------------------------------------------------------
                            341 ;temp                      Allocated to registers r7 
                            342 ;------------------------------------------------------------
                            343 ;	../key.c:19: uchar scanKey()
                            344 ;	-----------------------------------------
                            345 ;	 function scanKey
                            346 ;	-----------------------------------------
   073F                     347 _scanKey:
                    0007    348 	ar7 = 0x07
                    0006    349 	ar6 = 0x06
                    0005    350 	ar5 = 0x05
                    0004    351 	ar4 = 0x04
                    0003    352 	ar3 = 0x03
                    0002    353 	ar2 = 0x02
                    0001    354 	ar1 = 0x01
                    0000    355 	ar0 = 0x00
                            356 ;	../key.c:23: if (0 == KEY_A)
   073F 20 93 10            357 	jb	_KEY_A,00107$
                            358 ;	../key.c:25: delay_ms(15);
   0742 75 82 0F            359 	mov	dpl,#0x0F
   0745 12 07 27            360 	lcall	_delay_ms
                            361 ;	../key.c:26: if (0 == KEY_A)
   0748 20 93 07            362 	jb	_KEY_A,00107$
                            363 ;	../key.c:28: while(!KEY_A);
   074B                     364 00101$:
   074B 30 93 FD            365 	jnb	_KEY_A,00101$
                            366 ;	../key.c:29: return 16;
   074E 75 82 10            367 	mov	dpl,#0x10
   0751 22                  368 	ret
   0752                     369 00107$:
                            370 ;	../key.c:32: if (0 == KEY_B)
   0752 20 94 10            371 	jb	_KEY_B,00114$
                            372 ;	../key.c:34: delay_ms(15);
   0755 75 82 0F            373 	mov	dpl,#0x0F
   0758 12 07 27            374 	lcall	_delay_ms
                            375 ;	../key.c:35: if (0 == KEY_B)
   075B 20 94 07            376 	jb	_KEY_B,00114$
                            377 ;	../key.c:37: while(!KEY_B);
   075E                     378 00108$:
   075E 30 94 FD            379 	jnb	_KEY_B,00108$
                            380 ;	../key.c:38: return 17;
   0761 75 82 11            381 	mov	dpl,#0x11
   0764 22                  382 	ret
   0765                     383 00114$:
                            384 ;	../key.c:42: if (0 == KEY_C)
   0765 20 95 10            385 	jb	_KEY_C,00121$
                            386 ;	../key.c:44: delay_ms(15);
   0768 75 82 0F            387 	mov	dpl,#0x0F
   076B 12 07 27            388 	lcall	_delay_ms
                            389 ;	../key.c:45: if (0 == KEY_C)
   076E 20 95 07            390 	jb	_KEY_C,00121$
                            391 ;	../key.c:47: while(!KEY_C);
   0771                     392 00115$:
   0771 30 95 FD            393 	jnb	_KEY_C,00115$
                            394 ;	../key.c:48: return 18;
   0774 75 82 12            395 	mov	dpl,#0x12
   0777 22                  396 	ret
   0778                     397 00121$:
                            398 ;	../key.c:52: if (0 == KEY_D)
   0778 20 96 10            399 	jb	_KEY_D,00128$
                            400 ;	../key.c:54: delay_ms(15);
   077B 75 82 0F            401 	mov	dpl,#0x0F
   077E 12 07 27            402 	lcall	_delay_ms
                            403 ;	../key.c:55: if (0 == KEY_D)
   0781 20 96 07            404 	jb	_KEY_D,00128$
                            405 ;	../key.c:57: while(!KEY_D);
   0784                     406 00122$:
   0784 30 96 FD            407 	jnb	_KEY_D,00122$
                            408 ;	../key.c:58: return 19;
   0787 75 82 13            409 	mov	dpl,#0x13
   078A 22                  410 	ret
   078B                     411 00128$:
                            412 ;	../key.c:64: KEY_PORT=0xff; //����P1��д1���˿ڶ�״̬
   078B 75 A0 FF            413 	mov	_P2,#0xFF
                            414 ;	../key.c:65: KEY_PORT=0xf0;
   078E 75 A0 F0            415 	mov	_P2,#0xF0
                            416 ;	../key.c:67: temp=KEY_PORT;
   0791 AF A0               417 	mov	r7,_P2
                            418 ;	../key.c:68: if(temp!=0xf0)
   0793 E4                  419 	clr	a
   0794 BF F0 01            420 	cjne	r7,#0xF0,00336$
   0797 04                  421 	inc	a
   0798                     422 00336$:
   0798 FE                  423 	mov	r6,a
   0799 60 03               424 	jz	00338$
   079B 02 08 A8            425 	ljmp	00204$
   079E                     426 00338$:
                            427 ;	../key.c:70: delay_ms(15);
   079E 75 82 0F            428 	mov	dpl,#0x0F
   07A1 C0 06               429 	push	ar6
   07A3 12 07 27            430 	lcall	_delay_ms
   07A6 D0 06               431 	pop	ar6
                            432 ;	../key.c:71: if(temp!=0xf0)
   07A8 EE                  433 	mov	a,r6
   07A9 60 01               434 	jz	00339$
   07AB 22                  435 	ret
   07AC                     436 00339$:
                            437 ;	../key.c:73: KEY_PORT=0xfe;
   07AC 75 A0 FE            438 	mov	_P2,#0xFE
                            439 ;	../key.c:74: temp=KEY_PORT;
   07AF AF A0               440 	mov	r7,_P2
                            441 ;	../key.c:75: switch(temp)
   07B1 BF 7E 02            442 	cjne	r7,#0x7E,00340$
   07B4 80 2B               443 	sjmp	00142$
   07B6                     444 00340$:
   07B6 BF BE 02            445 	cjne	r7,#0xBE,00341$
   07B9 80 1C               446 	sjmp	00138$
   07BB                     447 00341$:
   07BB BF DE 02            448 	cjne	r7,#0xDE,00342$
   07BE 80 0D               449 	sjmp	00134$
   07C0                     450 00342$:
   07C0 BF EE 28            451 	cjne	r7,#0xEE,00146$
                            452 ;	../key.c:77: case(0xee):while(KEY_PORT == temp);return(0);break;
   07C3                     453 00130$:
   07C3 EF                  454 	mov	a,r7
   07C4 B5 A0 02            455 	cjne	a,_P2,00345$
   07C7 80 FA               456 	sjmp	00130$
   07C9                     457 00345$:
   07C9 75 82 00            458 	mov	dpl,#0x00
   07CC 22                  459 	ret
                            460 ;	../key.c:78: case(0xde):while(KEY_PORT == temp);return(1);break;
   07CD                     461 00134$:
   07CD EF                  462 	mov	a,r7
   07CE B5 A0 02            463 	cjne	a,_P2,00346$
   07D1 80 FA               464 	sjmp	00134$
   07D3                     465 00346$:
   07D3 75 82 01            466 	mov	dpl,#0x01
   07D6 22                  467 	ret
                            468 ;	../key.c:79: case(0xbe):while(KEY_PORT == temp);return(2);break;
   07D7                     469 00138$:
   07D7 EF                  470 	mov	a,r7
   07D8 B5 A0 02            471 	cjne	a,_P2,00347$
   07DB 80 FA               472 	sjmp	00138$
   07DD                     473 00347$:
   07DD 75 82 02            474 	mov	dpl,#0x02
   07E0 22                  475 	ret
                            476 ;	../key.c:80: case(0x7e):while(KEY_PORT == temp);return(3);break;
   07E1                     477 00142$:
   07E1 EF                  478 	mov	a,r7
   07E2 B5 A0 02            479 	cjne	a,_P2,00348$
   07E5 80 FA               480 	sjmp	00142$
   07E7                     481 00348$:
   07E7 75 82 03            482 	mov	dpl,#0x03
   07EA 22                  483 	ret
                            484 ;	../key.c:83: }
   07EB                     485 00146$:
                            486 ;	../key.c:85: KEY_PORT=0xfd;
   07EB 75 A0 FD            487 	mov	_P2,#0xFD
                            488 ;	../key.c:86: temp=KEY_PORT;
   07EE AF A0               489 	mov	r7,_P2
                            490 ;	../key.c:87: switch(temp)
   07F0 BF 7D 02            491 	cjne	r7,#0x7D,00349$
   07F3 80 2B               492 	sjmp	00160$
   07F5                     493 00349$:
   07F5 BF BD 02            494 	cjne	r7,#0xBD,00350$
   07F8 80 1C               495 	sjmp	00156$
   07FA                     496 00350$:
   07FA BF DD 02            497 	cjne	r7,#0xDD,00351$
   07FD 80 0D               498 	sjmp	00152$
   07FF                     499 00351$:
   07FF BF ED 28            500 	cjne	r7,#0xED,00164$
                            501 ;	../key.c:89: case(0xed):while(KEY_PORT == temp);return(4);break;
   0802                     502 00148$:
   0802 EF                  503 	mov	a,r7
   0803 B5 A0 02            504 	cjne	a,_P2,00354$
   0806 80 FA               505 	sjmp	00148$
   0808                     506 00354$:
   0808 75 82 04            507 	mov	dpl,#0x04
   080B 22                  508 	ret
                            509 ;	../key.c:90: case(0xdd):while(KEY_PORT == temp);return(5);break;
   080C                     510 00152$:
   080C EF                  511 	mov	a,r7
   080D B5 A0 02            512 	cjne	a,_P2,00355$
   0810 80 FA               513 	sjmp	00152$
   0812                     514 00355$:
   0812 75 82 05            515 	mov	dpl,#0x05
   0815 22                  516 	ret
                            517 ;	../key.c:91: case(0xbd):while(KEY_PORT == temp);return(6);break;
   0816                     518 00156$:
   0816 EF                  519 	mov	a,r7
   0817 B5 A0 02            520 	cjne	a,_P2,00356$
   081A 80 FA               521 	sjmp	00156$
   081C                     522 00356$:
   081C 75 82 06            523 	mov	dpl,#0x06
   081F 22                  524 	ret
                            525 ;	../key.c:92: case(0x7d):while(KEY_PORT == temp);return(7);break;
   0820                     526 00160$:
   0820 EF                  527 	mov	a,r7
   0821 B5 A0 02            528 	cjne	a,_P2,00357$
   0824 80 FA               529 	sjmp	00160$
   0826                     530 00357$:
   0826 75 82 07            531 	mov	dpl,#0x07
   0829 22                  532 	ret
                            533 ;	../key.c:95: }
   082A                     534 00164$:
                            535 ;	../key.c:97: KEY_PORT=0xfb;
   082A 75 A0 FB            536 	mov	_P2,#0xFB
                            537 ;	../key.c:98: temp=KEY_PORT;
   082D AF A0               538 	mov	r7,_P2
                            539 ;	../key.c:99: switch(temp)
   082F BF 7B 02            540 	cjne	r7,#0x7B,00358$
   0832 80 2B               541 	sjmp	00178$
   0834                     542 00358$:
   0834 BF BB 02            543 	cjne	r7,#0xBB,00359$
   0837 80 1C               544 	sjmp	00174$
   0839                     545 00359$:
   0839 BF DB 02            546 	cjne	r7,#0xDB,00360$
   083C 80 0D               547 	sjmp	00170$
   083E                     548 00360$:
   083E BF EB 28            549 	cjne	r7,#0xEB,00182$
                            550 ;	../key.c:101: case(0xeb):while(KEY_PORT == temp);return(8);break;
   0841                     551 00166$:
   0841 EF                  552 	mov	a,r7
   0842 B5 A0 02            553 	cjne	a,_P2,00363$
   0845 80 FA               554 	sjmp	00166$
   0847                     555 00363$:
   0847 75 82 08            556 	mov	dpl,#0x08
   084A 22                  557 	ret
                            558 ;	../key.c:102: case(0xdb):while(KEY_PORT == temp);return(9);break;
   084B                     559 00170$:
   084B EF                  560 	mov	a,r7
   084C B5 A0 02            561 	cjne	a,_P2,00364$
   084F 80 FA               562 	sjmp	00170$
   0851                     563 00364$:
   0851 75 82 09            564 	mov	dpl,#0x09
                            565 ;	../key.c:103: case(0xbb):while(KEY_PORT == temp);return(10);break;
   0854 22                  566 	ret
   0855                     567 00174$:
   0855 EF                  568 	mov	a,r7
   0856 B5 A0 02            569 	cjne	a,_P2,00365$
   0859 80 FA               570 	sjmp	00174$
   085B                     571 00365$:
   085B 75 82 0A            572 	mov	dpl,#0x0A
                            573 ;	../key.c:104: case(0x7b):while(KEY_PORT == temp);return(11);break;
   085E 22                  574 	ret
   085F                     575 00178$:
   085F EF                  576 	mov	a,r7
   0860 B5 A0 02            577 	cjne	a,_P2,00366$
   0863 80 FA               578 	sjmp	00178$
   0865                     579 00366$:
   0865 75 82 0B            580 	mov	dpl,#0x0B
                            581 ;	../key.c:107: }
   0868 22                  582 	ret
   0869                     583 00182$:
                            584 ;	../key.c:109: KEY_PORT=0xf7;
   0869 75 A0 F7            585 	mov	_P2,#0xF7
                            586 ;	../key.c:110: temp=KEY_PORT;
   086C AF A0               587 	mov	r7,_P2
                            588 ;	../key.c:111: switch(temp)
   086E BF 77 02            589 	cjne	r7,#0x77,00367$
   0871 80 2B               590 	sjmp	00196$
   0873                     591 00367$:
   0873 BF B7 02            592 	cjne	r7,#0xB7,00368$
   0876 80 1C               593 	sjmp	00192$
   0878                     594 00368$:
   0878 BF D7 02            595 	cjne	r7,#0xD7,00369$
   087B 80 0D               596 	sjmp	00188$
   087D                     597 00369$:
   087D BF E7 2B            598 	cjne	r7,#0xE7,00206$
                            599 ;	../key.c:113: case(0xe7):while(KEY_PORT == temp);return(12);break;
   0880                     600 00184$:
   0880 EF                  601 	mov	a,r7
   0881 B5 A0 02            602 	cjne	a,_P2,00372$
   0884 80 FA               603 	sjmp	00184$
   0886                     604 00372$:
   0886 75 82 0C            605 	mov	dpl,#0x0C
                            606 ;	../key.c:114: case(0xd7):while(KEY_PORT == temp);return(13);break;
   0889 22                  607 	ret
   088A                     608 00188$:
   088A EF                  609 	mov	a,r7
   088B B5 A0 02            610 	cjne	a,_P2,00373$
   088E 80 FA               611 	sjmp	00188$
   0890                     612 00373$:
   0890 75 82 0D            613 	mov	dpl,#0x0D
                            614 ;	../key.c:115: case(0xb7):while(KEY_PORT == temp);return(14);break;
   0893 22                  615 	ret
   0894                     616 00192$:
   0894 EF                  617 	mov	a,r7
   0895 B5 A0 02            618 	cjne	a,_P2,00374$
   0898 80 FA               619 	sjmp	00192$
   089A                     620 00374$:
   089A 75 82 0E            621 	mov	dpl,#0x0E
                            622 ;	../key.c:116: case(0x77):while(KEY_PORT == temp);return(15);break;
   089D 22                  623 	ret
   089E                     624 00196$:
   089E EF                  625 	mov	a,r7
   089F B5 A0 02            626 	cjne	a,_P2,00375$
   08A2 80 FA               627 	sjmp	00196$
   08A4                     628 00375$:
   08A4 75 82 0F            629 	mov	dpl,#0x0F
                            630 ;	../key.c:119: }
   08A7 22                  631 	ret
   08A8                     632 00204$:
                            633 ;	../key.c:123: return NO_KEY_PRESSED;
   08A8 75 82 37            634 	mov	dpl,#0x37
   08AB                     635 00206$:
   08AB 22                  636 	ret
                            637 ;------------------------------------------------------------
                            638 ;Allocation info for local variables in function 'scanKeyToInt'
                            639 ;------------------------------------------------------------
                            640 ;key                       Allocated to registers r7 
                            641 ;------------------------------------------------------------
                            642 ;	../key.c:129: uchar  scanKeyToInt()
                            643 ;	-----------------------------------------
                            644 ;	 function scanKeyToInt
                            645 ;	-----------------------------------------
   08AC                     646 _scanKeyToInt:
                            647 ;	../key.c:132: key = scanKey();
   08AC 12 07 3F            648 	lcall	_scanKey
   08AF AF 82               649 	mov	r7,dpl
                            650 ;	../key.c:133: if (NO_KEY_PRESSED == key) return NO_KEY_PRESSED;
   08B1 BF 37 04            651 	cjne	r7,#0x37,00102$
   08B4 75 82 37            652 	mov	dpl,#0x37
   08B7 22                  653 	ret
   08B8                     654 00102$:
                            655 ;	../key.c:134: switch(key)
   08B8 EF                  656 	mov	a,r7
   08B9 24 EC               657 	add	a,#0xff - 0x13
   08BB 50 03               658 	jnc	00133$
   08BD 02 09 45            659 	ljmp	00123$
   08C0                     660 00133$:
   08C0 EF                  661 	mov	a,r7
   08C1 24 09               662 	add	a,#(00134$-3-.)
   08C3 83                  663 	movc	a,@a+pc
   08C4 C0 E0               664 	push	acc
   08C6 EF                  665 	mov	a,r7
   08C7 24 17               666 	add	a,#(00135$-3-.)
   08C9 83                  667 	movc	a,@a+pc
   08CA C0 E0               668 	push	acc
   08CC 22                  669 	ret
   08CD                     670 00134$:
   08CD F5                  671 	.db	00103$
   08CE F9                  672 	.db	00104$
   08CF FD                  673 	.db	00105$
   08D0 01                  674 	.db	00106$
   08D1 05                  675 	.db	00107$
   08D2 09                  676 	.db	00108$
   08D3 0D                  677 	.db	00109$
   08D4 11                  678 	.db	00110$
   08D5 15                  679 	.db	00111$
   08D6 19                  680 	.db	00112$
   08D7 1D                  681 	.db	00113$
   08D8 21                  682 	.db	00114$
   08D9 25                  683 	.db	00115$
   08DA 29                  684 	.db	00116$
   08DB 2D                  685 	.db	00117$
   08DC 31                  686 	.db	00118$
   08DD 35                  687 	.db	00119$
   08DE 39                  688 	.db	00120$
   08DF 3D                  689 	.db	00121$
   08E0 41                  690 	.db	00122$
   08E1                     691 00135$:
   08E1 08                  692 	.db	00103$>>8
   08E2 08                  693 	.db	00104$>>8
   08E3 08                  694 	.db	00105$>>8
   08E4 09                  695 	.db	00106$>>8
   08E5 09                  696 	.db	00107$>>8
   08E6 09                  697 	.db	00108$>>8
   08E7 09                  698 	.db	00109$>>8
   08E8 09                  699 	.db	00110$>>8
   08E9 09                  700 	.db	00111$>>8
   08EA 09                  701 	.db	00112$>>8
   08EB 09                  702 	.db	00113$>>8
   08EC 09                  703 	.db	00114$>>8
   08ED 09                  704 	.db	00115$>>8
   08EE 09                  705 	.db	00116$>>8
   08EF 09                  706 	.db	00117$>>8
   08F0 09                  707 	.db	00118$>>8
   08F1 09                  708 	.db	00119$>>8
   08F2 09                  709 	.db	00120$>>8
   08F3 09                  710 	.db	00121$>>8
   08F4 09                  711 	.db	00122$>>8
                            712 ;	../key.c:136: case 0: return DIVID; break;
   08F5                     713 00103$:
   08F5 75 82 3B            714 	mov	dpl,#0x3B
                            715 ;	../key.c:137: case 1: return MULTI; break;
   08F8 22                  716 	ret
   08F9                     717 00104$:
   08F9 75 82 3A            718 	mov	dpl,#0x3A
                            719 ;	../key.c:138: case 2: return MINUS; break;
   08FC 22                  720 	ret
   08FD                     721 00105$:
   08FD 75 82 39            722 	mov	dpl,#0x39
                            723 ;	../key.c:139: case 3: return PLUS;  break;
   0900 22                  724 	ret
   0901                     725 00106$:
   0901 75 82 38            726 	mov	dpl,#0x38
                            727 ;	../key.c:140: case 4: return 9; break;
   0904 22                  728 	ret
   0905                     729 00107$:
   0905 75 82 09            730 	mov	dpl,#0x09
                            731 ;	../key.c:141: case 5: return 6; break;
   0908 22                  732 	ret
   0909                     733 00108$:
   0909 75 82 06            734 	mov	dpl,#0x06
                            735 ;	../key.c:142: case 6: return 3; break;
   090C 22                  736 	ret
   090D                     737 00109$:
   090D 75 82 03            738 	mov	dpl,#0x03
                            739 ;	../key.c:143: case 7: return EQUAL; break;
   0910 22                  740 	ret
   0911                     741 00110$:
   0911 75 82 3C            742 	mov	dpl,#0x3C
                            743 ;	../key.c:144: case 8: return 8; break;
   0914 22                  744 	ret
   0915                     745 00111$:
   0915 75 82 08            746 	mov	dpl,#0x08
                            747 ;	../key.c:145: case 9: return 5; break;
   0918 22                  748 	ret
   0919                     749 00112$:
   0919 75 82 05            750 	mov	dpl,#0x05
                            751 ;	../key.c:146: case 10: return 2; break;
   091C 22                  752 	ret
   091D                     753 00113$:
   091D 75 82 02            754 	mov	dpl,#0x02
                            755 ;	../key.c:147: case 11: return 0; break;
   0920 22                  756 	ret
   0921                     757 00114$:
   0921 75 82 00            758 	mov	dpl,#0x00
                            759 ;	../key.c:148: case 12: return 7; break;
   0924 22                  760 	ret
   0925                     761 00115$:
   0925 75 82 07            762 	mov	dpl,#0x07
                            763 ;	../key.c:149: case 13: return 4; break;
   0928 22                  764 	ret
   0929                     765 00116$:
   0929 75 82 04            766 	mov	dpl,#0x04
                            767 ;	../key.c:150: case 14: return 1; break;
   092C 22                  768 	ret
   092D                     769 00117$:
   092D 75 82 01            770 	mov	dpl,#0x01
                            771 ;	../key.c:151: case 15: return CE; break;
   0930 22                  772 	ret
   0931                     773 00118$:
   0931 75 82 3D            774 	mov	dpl,#0x3D
                            775 ;	../key.c:152: case 16: return SQR; break;
   0934 22                  776 	ret
   0935                     777 00119$:
   0935 75 82 40            778 	mov	dpl,#0x40
                            779 ;	../key.c:153: case 17: return SIN; break;
   0938 22                  780 	ret
   0939                     781 00120$:
   0939 75 82 3E            782 	mov	dpl,#0x3E
                            783 ;	../key.c:154: case 18: return COS; break;
   093C 22                  784 	ret
   093D                     785 00121$:
   093D 75 82 3F            786 	mov	dpl,#0x3F
                            787 ;	../key.c:155: case 19: return CE; break;
   0940 22                  788 	ret
   0941                     789 00122$:
   0941 75 82 3D            790 	mov	dpl,#0x3D
                            791 ;	../key.c:156: default:
   0944 22                  792 	ret
   0945                     793 00123$:
                            794 ;	../key.c:157: return NAN; break;
   0945 75 82 63            795 	mov	dpl,#0x63
                            796 ;	../key.c:158: }
   0948 22                  797 	ret
                            798 	.area CSEG    (CODE)
                            799 	.area CONST   (CODE)
                            800 	.area XINIT   (CODE)
                            801 	.area CABS    (ABS,CODE)
