                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : free open source ANSI-C Compiler
                              3 ; Version 3.1.4 #7658 (May  3 2012) (Linux)
                              4 ; This file was generated Mon May 21 12:35:53 2012
                              5 ;--------------------------------------------------------
                              6 	.module calc
                              7 	.optsdcc -mmcs51 --model-small
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _goToXY
                             13 	.globl _input_cursor_left_shift
                             14 	.globl _clrscr
                             15 	.globl _lcd_write_string
                             16 	.globl _write_data
                             17 	.globl _scanKeyToInt
                             18 	.globl _BF
                             19 	.globl _E
                             20 	.globl _RW
                             21 	.globl _RS
                             22 	.globl _KEY_D
                             23 	.globl _KEY_C
                             24 	.globl _KEY_B
                             25 	.globl _KEY_A
                             26 	.globl _TF2
                             27 	.globl _EXF2
                             28 	.globl _RCLK
                             29 	.globl _TCLK
                             30 	.globl _EXEN2
                             31 	.globl _TR2
                             32 	.globl _C_T2
                             33 	.globl _CP_RL2
                             34 	.globl _T2CON_7
                             35 	.globl _T2CON_6
                             36 	.globl _T2CON_5
                             37 	.globl _T2CON_4
                             38 	.globl _T2CON_3
                             39 	.globl _T2CON_2
                             40 	.globl _T2CON_1
                             41 	.globl _T2CON_0
                             42 	.globl _PT2
                             43 	.globl _ET2
                             44 	.globl _CY
                             45 	.globl _AC
                             46 	.globl _F0
                             47 	.globl _RS1
                             48 	.globl _RS0
                             49 	.globl _OV
                             50 	.globl _F1
                             51 	.globl _P
                             52 	.globl _PS
                             53 	.globl _PT1
                             54 	.globl _PX1
                             55 	.globl _PT0
                             56 	.globl _PX0
                             57 	.globl _RD
                             58 	.globl _WR
                             59 	.globl _T1
                             60 	.globl _T0
                             61 	.globl _INT1
                             62 	.globl _INT0
                             63 	.globl _TXD
                             64 	.globl _RXD
                             65 	.globl _P3_7
                             66 	.globl _P3_6
                             67 	.globl _P3_5
                             68 	.globl _P3_4
                             69 	.globl _P3_3
                             70 	.globl _P3_2
                             71 	.globl _P3_1
                             72 	.globl _P3_0
                             73 	.globl _EA
                             74 	.globl _ES
                             75 	.globl _ET1
                             76 	.globl _EX1
                             77 	.globl _ET0
                             78 	.globl _EX0
                             79 	.globl _P2_7
                             80 	.globl _P2_6
                             81 	.globl _P2_5
                             82 	.globl _P2_4
                             83 	.globl _P2_3
                             84 	.globl _P2_2
                             85 	.globl _P2_1
                             86 	.globl _P2_0
                             87 	.globl _SM0
                             88 	.globl _SM1
                             89 	.globl _SM2
                             90 	.globl _REN
                             91 	.globl _TB8
                             92 	.globl _RB8
                             93 	.globl _TI
                             94 	.globl _RI
                             95 	.globl _P1_7
                             96 	.globl _P1_6
                             97 	.globl _P1_5
                             98 	.globl _P1_4
                             99 	.globl _P1_3
                            100 	.globl _P1_2
                            101 	.globl _P1_1
                            102 	.globl _P1_0
                            103 	.globl _TF1
                            104 	.globl _TR1
                            105 	.globl _TF0
                            106 	.globl _TR0
                            107 	.globl _IE1
                            108 	.globl _IT1
                            109 	.globl _IE0
                            110 	.globl _IT0
                            111 	.globl _P0_7
                            112 	.globl _P0_6
                            113 	.globl _P0_5
                            114 	.globl _P0_4
                            115 	.globl _P0_3
                            116 	.globl _P0_2
                            117 	.globl _P0_1
                            118 	.globl _P0_0
                            119 	.globl _TH2
                            120 	.globl _TL2
                            121 	.globl _RCAP2H
                            122 	.globl _RCAP2L
                            123 	.globl _T2CON
                            124 	.globl _B
                            125 	.globl _ACC
                            126 	.globl _PSW
                            127 	.globl _IP
                            128 	.globl _P3
                            129 	.globl _IE
                            130 	.globl _P2
                            131 	.globl _SBUF
                            132 	.globl _SCON
                            133 	.globl _P1
                            134 	.globl _TH1
                            135 	.globl _TH0
                            136 	.globl _TL1
                            137 	.globl _TL0
                            138 	.globl _TMOD
                            139 	.globl _TCON
                            140 	.globl _PCON
                            141 	.globl _DPH
                            142 	.globl _DPL
                            143 	.globl _SP
                            144 	.globl _P0
                            145 	.globl _ERR
                            146 	.globl _DBZ
                            147 	.globl _flag
                            148 	.globl _fuhao
                            149 	.globl _RESULT
                            150 	.globl _INPUTB
                            151 	.globl _INPUTA
                            152 	.globl _calc_init
                            153 	.globl _calc
                            154 ;--------------------------------------------------------
                            155 ; special function registers
                            156 ;--------------------------------------------------------
                            157 	.area RSEG    (ABS,DATA)
   0000                     158 	.org 0x0000
                    0080    159 _P0	=	0x0080
                    0081    160 _SP	=	0x0081
                    0082    161 _DPL	=	0x0082
                    0083    162 _DPH	=	0x0083
                    0087    163 _PCON	=	0x0087
                    0088    164 _TCON	=	0x0088
                    0089    165 _TMOD	=	0x0089
                    008A    166 _TL0	=	0x008a
                    008B    167 _TL1	=	0x008b
                    008C    168 _TH0	=	0x008c
                    008D    169 _TH1	=	0x008d
                    0090    170 _P1	=	0x0090
                    0098    171 _SCON	=	0x0098
                    0099    172 _SBUF	=	0x0099
                    00A0    173 _P2	=	0x00a0
                    00A8    174 _IE	=	0x00a8
                    00B0    175 _P3	=	0x00b0
                    00B8    176 _IP	=	0x00b8
                    00D0    177 _PSW	=	0x00d0
                    00E0    178 _ACC	=	0x00e0
                    00F0    179 _B	=	0x00f0
                    00C8    180 _T2CON	=	0x00c8
                    00CA    181 _RCAP2L	=	0x00ca
                    00CB    182 _RCAP2H	=	0x00cb
                    00CC    183 _TL2	=	0x00cc
                    00CD    184 _TH2	=	0x00cd
                            185 ;--------------------------------------------------------
                            186 ; special function bits
                            187 ;--------------------------------------------------------
                            188 	.area RSEG    (ABS,DATA)
   0000                     189 	.org 0x0000
                    0080    190 _P0_0	=	0x0080
                    0081    191 _P0_1	=	0x0081
                    0082    192 _P0_2	=	0x0082
                    0083    193 _P0_3	=	0x0083
                    0084    194 _P0_4	=	0x0084
                    0085    195 _P0_5	=	0x0085
                    0086    196 _P0_6	=	0x0086
                    0087    197 _P0_7	=	0x0087
                    0088    198 _IT0	=	0x0088
                    0089    199 _IE0	=	0x0089
                    008A    200 _IT1	=	0x008a
                    008B    201 _IE1	=	0x008b
                    008C    202 _TR0	=	0x008c
                    008D    203 _TF0	=	0x008d
                    008E    204 _TR1	=	0x008e
                    008F    205 _TF1	=	0x008f
                    0090    206 _P1_0	=	0x0090
                    0091    207 _P1_1	=	0x0091
                    0092    208 _P1_2	=	0x0092
                    0093    209 _P1_3	=	0x0093
                    0094    210 _P1_4	=	0x0094
                    0095    211 _P1_5	=	0x0095
                    0096    212 _P1_6	=	0x0096
                    0097    213 _P1_7	=	0x0097
                    0098    214 _RI	=	0x0098
                    0099    215 _TI	=	0x0099
                    009A    216 _RB8	=	0x009a
                    009B    217 _TB8	=	0x009b
                    009C    218 _REN	=	0x009c
                    009D    219 _SM2	=	0x009d
                    009E    220 _SM1	=	0x009e
                    009F    221 _SM0	=	0x009f
                    00A0    222 _P2_0	=	0x00a0
                    00A1    223 _P2_1	=	0x00a1
                    00A2    224 _P2_2	=	0x00a2
                    00A3    225 _P2_3	=	0x00a3
                    00A4    226 _P2_4	=	0x00a4
                    00A5    227 _P2_5	=	0x00a5
                    00A6    228 _P2_6	=	0x00a6
                    00A7    229 _P2_7	=	0x00a7
                    00A8    230 _EX0	=	0x00a8
                    00A9    231 _ET0	=	0x00a9
                    00AA    232 _EX1	=	0x00aa
                    00AB    233 _ET1	=	0x00ab
                    00AC    234 _ES	=	0x00ac
                    00AF    235 _EA	=	0x00af
                    00B0    236 _P3_0	=	0x00b0
                    00B1    237 _P3_1	=	0x00b1
                    00B2    238 _P3_2	=	0x00b2
                    00B3    239 _P3_3	=	0x00b3
                    00B4    240 _P3_4	=	0x00b4
                    00B5    241 _P3_5	=	0x00b5
                    00B6    242 _P3_6	=	0x00b6
                    00B7    243 _P3_7	=	0x00b7
                    00B0    244 _RXD	=	0x00b0
                    00B1    245 _TXD	=	0x00b1
                    00B2    246 _INT0	=	0x00b2
                    00B3    247 _INT1	=	0x00b3
                    00B4    248 _T0	=	0x00b4
                    00B5    249 _T1	=	0x00b5
                    00B6    250 _WR	=	0x00b6
                    00B7    251 _RD	=	0x00b7
                    00B8    252 _PX0	=	0x00b8
                    00B9    253 _PT0	=	0x00b9
                    00BA    254 _PX1	=	0x00ba
                    00BB    255 _PT1	=	0x00bb
                    00BC    256 _PS	=	0x00bc
                    00D0    257 _P	=	0x00d0
                    00D1    258 _F1	=	0x00d1
                    00D2    259 _OV	=	0x00d2
                    00D3    260 _RS0	=	0x00d3
                    00D4    261 _RS1	=	0x00d4
                    00D5    262 _F0	=	0x00d5
                    00D6    263 _AC	=	0x00d6
                    00D7    264 _CY	=	0x00d7
                    00AD    265 _ET2	=	0x00ad
                    00BD    266 _PT2	=	0x00bd
                    00C8    267 _T2CON_0	=	0x00c8
                    00C9    268 _T2CON_1	=	0x00c9
                    00CA    269 _T2CON_2	=	0x00ca
                    00CB    270 _T2CON_3	=	0x00cb
                    00CC    271 _T2CON_4	=	0x00cc
                    00CD    272 _T2CON_5	=	0x00cd
                    00CE    273 _T2CON_6	=	0x00ce
                    00CF    274 _T2CON_7	=	0x00cf
                    00C8    275 _CP_RL2	=	0x00c8
                    00C9    276 _C_T2	=	0x00c9
                    00CA    277 _TR2	=	0x00ca
                    00CB    278 _EXEN2	=	0x00cb
                    00CC    279 _TCLK	=	0x00cc
                    00CD    280 _RCLK	=	0x00cd
                    00CE    281 _EXF2	=	0x00ce
                    00CF    282 _TF2	=	0x00cf
                    0093    283 _KEY_A	=	0x0093
                    0094    284 _KEY_B	=	0x0094
                    0095    285 _KEY_C	=	0x0095
                    0096    286 _KEY_D	=	0x0096
                    0090    287 _RS	=	0x0090
                    0091    288 _RW	=	0x0091
                    0092    289 _E	=	0x0092
                    0087    290 _BF	=	0x0087
                            291 ;--------------------------------------------------------
                            292 ; overlayable register banks
                            293 ;--------------------------------------------------------
                            294 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     295 	.ds 8
                            296 ;--------------------------------------------------------
                            297 ; internal ram data
                            298 ;--------------------------------------------------------
                            299 	.area DSEG    (DATA)
   0021                     300 _INPUTA::
   0021                     301 	.ds 4
   0025                     302 _INPUTB::
   0025                     303 	.ds 4
   0029                     304 _RESULT::
   0029                     305 	.ds 4
   002D                     306 _fuhao::
   002D                     307 	.ds 1
   002E                     308 _flag::
   002E                     309 	.ds 1
   002F                     310 _DBZ::
   002F                     311 	.ds 3
   0032                     312 _ERR::
   0032                     313 	.ds 3
   0035                     314 _calc_key_1_28:
   0035                     315 	.ds 1
   0036                     316 _calc_sloc0_1_0:
   0036                     317 	.ds 4
                            318 ;--------------------------------------------------------
                            319 ; overlayable items in internal ram 
                            320 ;--------------------------------------------------------
                            321 ;--------------------------------------------------------
                            322 ; indirectly addressable internal ram data
                            323 ;--------------------------------------------------------
                            324 	.area ISEG    (DATA)
                            325 ;--------------------------------------------------------
                            326 ; absolute internal ram data
                            327 ;--------------------------------------------------------
                            328 	.area IABS    (ABS,DATA)
                            329 	.area IABS    (ABS,DATA)
                            330 ;--------------------------------------------------------
                            331 ; bit data
                            332 ;--------------------------------------------------------
                            333 	.area BSEG    (BIT)
                            334 ;--------------------------------------------------------
                            335 ; paged external ram data
                            336 ;--------------------------------------------------------
                            337 	.area PSEG    (PAG,XDATA)
                            338 ;--------------------------------------------------------
                            339 ; external ram data
                            340 ;--------------------------------------------------------
                            341 	.area XSEG    (XDATA)
                            342 ;--------------------------------------------------------
                            343 ; absolute external ram data
                            344 ;--------------------------------------------------------
                            345 	.area XABS    (ABS,XDATA)
                            346 ;--------------------------------------------------------
                            347 ; external initialized ram data
                            348 ;--------------------------------------------------------
                            349 	.area XISEG   (XDATA)
                            350 	.area HOME    (CODE)
                            351 	.area GSINIT0 (CODE)
                            352 	.area GSINIT1 (CODE)
                            353 	.area GSINIT2 (CODE)
                            354 	.area GSINIT3 (CODE)
                            355 	.area GSINIT4 (CODE)
                            356 	.area GSINIT5 (CODE)
                            357 	.area GSINIT  (CODE)
                            358 	.area GSFINAL (CODE)
                            359 	.area CSEG    (CODE)
                            360 ;--------------------------------------------------------
                            361 ; global & static initialisations
                            362 ;--------------------------------------------------------
                            363 	.area HOME    (CODE)
                            364 	.area GSINIT  (CODE)
                            365 	.area GSFINAL (CODE)
                            366 	.area GSINIT  (CODE)
                            367 ;	../calc.c:17: unsigned char fuhao = 0, flag = 0; //fuhao��ʾ���µ���������ͣ�flag��ʾ�Ƿ������������
   0061 75 2D 00            368 	mov	_fuhao,#0x00
                            369 ;	../calc.c:17: 
   0064 75 2E 00            370 	mov	_flag,#0x00
                            371 ;	../calc.c:19: const char *DBZ = "Divided by zero!";
   0067 75 2F 15            372 	mov	_DBZ,#__str_0
   006A 75 30 10            373 	mov	(_DBZ + 1),#(__str_0 >> 8)
   006D 75 31 80            374 	mov	(_DBZ + 2),#0x80
                            375 ;	../calc.c:20: const char *ERR = "Error!";
   0070 75 32 26            376 	mov	_ERR,#__str_1
   0073 75 33 10            377 	mov	(_ERR + 1),#(__str_1 >> 8)
   0076 75 34 80            378 	mov	(_ERR + 2),#0x80
                            379 ;--------------------------------------------------------
                            380 ; Home
                            381 ;--------------------------------------------------------
                            382 	.area HOME    (CODE)
                            383 	.area HOME    (CODE)
                            384 ;--------------------------------------------------------
                            385 ; code
                            386 ;--------------------------------------------------------
                            387 	.area CSEG    (CODE)
                            388 ;------------------------------------------------------------
                            389 ;Allocation info for local variables in function 'calc_init'
                            390 ;------------------------------------------------------------
                            391 ;	../calc.c:115: calc_init(void)
                            392 ;	-----------------------------------------
                            393 ;	 function calc_init
                            394 ;	-----------------------------------------
   007C                     395 _calc_init:
                    0007    396 	ar7 = 0x07
                    0006    397 	ar6 = 0x06
                    0005    398 	ar5 = 0x05
                    0004    399 	ar4 = 0x04
                    0003    400 	ar3 = 0x03
                    0002    401 	ar2 = 0x02
                    0001    402 	ar1 = 0x01
                    0000    403 	ar0 = 0x00
                            404 ;	../calc.c:117: INPUTA = INPUTB = RESULT = 0;
   007C E4                  405 	clr	a
   007D F5 29               406 	mov	_RESULT,a
   007F F5 2A               407 	mov	(_RESULT + 1),a
   0081 F5 2B               408 	mov	(_RESULT + 2),a
   0083 F5 2C               409 	mov	(_RESULT + 3),a
   0085 F5 25               410 	mov	_INPUTB,a
   0087 F5 26               411 	mov	(_INPUTB + 1),a
   0089 F5 27               412 	mov	(_INPUTB + 2),a
   008B F5 28               413 	mov	(_INPUTB + 3),a
                            414 ;	../calc.c:118: flag = 0;
                            415 ;	../calc.c:119: fuhao = 0;
   008D E4                  416 	clr a
   008E F5 21               417 	mov _INPUTA,a
   0090 F5 22               418 	mov (_INPUTA + 1),a
   0092 F5 23               419 	mov (_INPUTA + 2),a
   0094 F5 24               420 	mov (_INPUTA + 3),a
   0096 F5 2E               421 	mov _flag,a
   0098 F5 2D               422 	mov _fuhao,a
                            423 ;	../calc.c:121: goToXY(1, 1);
   009A 75 08 01            424 	mov	_goToXY_PARM_2,#0x01
   009D 75 82 01            425 	mov	dpl,#0x01
   00A0 02 0A 99            426 	ljmp	_goToXY
                            427 ;------------------------------------------------------------
                            428 ;Allocation info for local variables in function 'calc'
                            429 ;------------------------------------------------------------
                            430 ;key                       Allocated with name '_calc_key_1_28'
                            431 ;i                         Allocated to registers r6 
                            432 ;sloc0                     Allocated with name '_calc_sloc0_1_0'
                            433 ;------------------------------------------------------------
                            434 ;	../calc.c:125: calc(void)
                            435 ;	-----------------------------------------
                            436 ;	 function calc
                            437 ;	-----------------------------------------
   00A3                     438 _calc:
                            439 ;	../calc.c:128: key = scanKeyToInt();
   00A3 12 08 AC            440 	lcall	_scanKeyToInt
   00A6 85 82 35            441 	mov	_calc_key_1_28,dpl
                            442 ;	../calc.c:129: if (key == NO_KEY_PRESSED)
   00A9 74 37               443 	mov	a,#0x37
   00AB B5 35 01            444 	cjne	a,_calc_key_1_28,00102$
                            445 ;	../calc.c:130: return; //���û�а������£�ֱ�ӷ���
   00AE 22                  446 	ret
   00AF                     447 00102$:
                            448 ;	../calc.c:131: if (key == CE)
   00AF 74 3D               449 	mov	a,#0x3D
   00B1 B5 35 06            450 	cjne	a,_calc_key_1_28,00104$
                            451 ;	../calc.c:133: clrscr();
   00B4 12 0A 2D            452 	lcall	_clrscr
                            453 ;	../calc.c:134: calc_init();
                            454 ;	../calc.c:135: return;
   00B7 02 00 7C            455 	ljmp	_calc_init
   00BA                     456 00104$:
                            457 ;	../calc.c:137: if (key == SQR)
   00BA 74 40               458 	mov	a,#0x40
   00BC B5 35 02            459 	cjne	a,_calc_key_1_28,00261$
   00BF 80 03               460 	sjmp	00262$
   00C1                     461 00261$:
   00C1 02 01 80            462 	ljmp	00112$
   00C4                     463 00262$:
                            464 ;	../calc.c:139: if (flag != 1)
   00C4 74 01               465 	mov	a,#0x01
   00C6 B5 2E 03            466 	cjne	a,_flag,00263$
   00C9 02 01 65            467 	ljmp	00109$
   00CC                     468 00263$:
                            469 ;	../calc.c:141: RESULT = INPUTA * INPUTA;
   00CC 85 21 09            470 	mov	__mullong_PARM_2,_INPUTA
   00CF 85 22 0A            471 	mov	(__mullong_PARM_2 + 1),(_INPUTA + 1)
   00D2 85 23 0B            472 	mov	(__mullong_PARM_2 + 2),(_INPUTA + 2)
   00D5 85 24 0C            473 	mov	(__mullong_PARM_2 + 3),(_INPUTA + 3)
   00D8 85 21 82            474 	mov	dpl,_INPUTA
   00DB 85 22 83            475 	mov	dph,(_INPUTA + 1)
   00DE 85 23 F0            476 	mov	b,(_INPUTA + 2)
   00E1 E5 24               477 	mov	a,(_INPUTA + 3)
   00E3 12 0D 91            478 	lcall	__mullong
   00E6 85 82 29            479 	mov	_RESULT,dpl
   00E9 85 83 2A            480 	mov	(_RESULT + 1),dph
   00EC 85 F0 2B            481 	mov	(_RESULT + 2),b
   00EF F5 2C               482 	mov	(_RESULT + 3),a
                            483 ;	../calc.c:142: write_data('^');
   00F1 75 82 5E            484 	mov	dpl,#0x5E
   00F4 12 09 8C            485 	lcall	_write_data
                            486 ;	../calc.c:143: write_data('2');
   00F7 75 82 32            487 	mov	dpl,#0x32
   00FA 12 09 8C            488 	lcall	_write_data
                            489 ;	../calc.c:144: goToXY(2, 15);
   00FD 75 08 0F            490 	mov	_goToXY_PARM_2,#0x0F
   0100 75 82 02            491 	mov	dpl,#0x02
   0103 12 0A 99            492 	lcall	_goToXY
                            493 ;	../calc.c:145: input_cursor_left_shift();
   0106 12 0A 75            494 	lcall	_input_cursor_left_shift
                            495 ;	../calc.c:146: while (RESULT != 0)
   0109                     496 00105$:
   0109 E5 29               497 	mov	a,_RESULT
   010B 45 2A               498 	orl	a,(_RESULT + 1)
   010D 45 2B               499 	orl	a,(_RESULT + 2)
   010F 45 2C               500 	orl	a,(_RESULT + 3)
   0111 60 47               501 	jz	00107$
                            502 ;	../calc.c:148: write_data(0x30 + RESULT % 10);
   0113 75 09 0A            503 	mov	__modslong_PARM_2,#0x0A
   0116 E4                  504 	clr	a
   0117 F5 0A               505 	mov	(__modslong_PARM_2 + 1),a
   0119 F5 0B               506 	mov	(__modslong_PARM_2 + 2),a
   011B F5 0C               507 	mov	(__modslong_PARM_2 + 3),a
   011D 85 29 82            508 	mov	dpl,_RESULT
   0120 85 2A 83            509 	mov	dph,(_RESULT + 1)
   0123 85 2B F0            510 	mov	b,(_RESULT + 2)
   0126 E5 2C               511 	mov	a,(_RESULT + 3)
   0128 12 0D FF            512 	lcall	__modslong
   012B AB 82               513 	mov	r3,dpl
   012D 74 30               514 	mov	a,#0x30
   012F 2B                  515 	add	a,r3
   0130 F5 82               516 	mov	dpl,a
   0132 12 09 8C            517 	lcall	_write_data
                            518 ;	../calc.c:149: RESULT /= 10;
   0135 75 09 0A            519 	mov	__divslong_PARM_2,#0x0A
   0138 E4                  520 	clr	a
   0139 F5 0A               521 	mov	(__divslong_PARM_2 + 1),a
   013B F5 0B               522 	mov	(__divslong_PARM_2 + 2),a
   013D F5 0C               523 	mov	(__divslong_PARM_2 + 3),a
   013F 85 29 82            524 	mov	dpl,_RESULT
   0142 85 2A 83            525 	mov	dph,(_RESULT + 1)
   0145 85 2B F0            526 	mov	b,(_RESULT + 2)
   0148 E5 2C               527 	mov	a,(_RESULT + 3)
   014A 12 0E 4E            528 	lcall	__divslong
   014D 85 82 29            529 	mov	_RESULT,dpl
   0150 85 83 2A            530 	mov	(_RESULT + 1),dph
   0153 85 F0 2B            531 	mov	(_RESULT + 2),b
   0156 F5 2C               532 	mov	(_RESULT + 3),a
   0158 80 AF               533 	sjmp	00105$
   015A                     534 00107$:
                            535 ;	../calc.c:151: write_data('=');
   015A 75 82 3D            536 	mov	dpl,#0x3D
   015D 12 09 8C            537 	lcall	_write_data
                            538 ;	../calc.c:152: calc_init();
   0160 12 00 7C            539 	lcall	_calc_init
   0163 80 1B               540 	sjmp	00112$
   0165                     541 00109$:
                            542 ;	../calc.c:156: clrscr();
   0165 12 0A 2D            543 	lcall	_clrscr
                            544 ;	../calc.c:157: goToXY(1, 1);
   0168 75 08 01            545 	mov	_goToXY_PARM_2,#0x01
   016B 75 82 01            546 	mov	dpl,#0x01
   016E 12 0A 99            547 	lcall	_goToXY
                            548 ;	../calc.c:158: lcd_write_string(ERR);
   0171 85 32 82            549 	mov	dpl,_ERR
   0174 85 33 83            550 	mov	dph,(_ERR + 1)
   0177 85 34 F0            551 	mov	b,(_ERR + 2)
   017A 12 0A 02            552 	lcall	_lcd_write_string
                            553 ;	../calc.c:159: calc_init();
                            554 ;	../calc.c:160: return;
   017D 02 00 7C            555 	ljmp	_calc_init
   0180                     556 00112$:
                            557 ;	../calc.c:200: if (key == PLUS)
   0180 74 38               558 	mov	a,#0x38
   0182 B5 35 2F            559 	cjne	a,_calc_key_1_28,00117$
                            560 ;	../calc.c:202: if (flag != 1)
   0185 74 01               561 	mov	a,#0x01
   0187 B5 2E 02            562 	cjne	a,_flag,00267$
   018A 80 0D               563 	sjmp	00114$
   018C                     564 00267$:
                            565 ;	../calc.c:204: fuhao = PLUS;
   018C 75 2D 38            566 	mov	_fuhao,#0x38
                            567 ;	../calc.c:205: write_data('+');
   018F 75 82 2B            568 	mov	dpl,#0x2B
   0192 12 09 8C            569 	lcall	_write_data
                            570 ;	../calc.c:206: flag = 1;
   0195 75 2E 01            571 	mov	_flag,#0x01
                            572 ;	../calc.c:207: return;
   0198 22                  573 	ret
   0199                     574 00114$:
                            575 ;	../calc.c:211: clrscr();
   0199 12 0A 2D            576 	lcall	_clrscr
                            577 ;	../calc.c:212: goToXY(1, 1);
   019C 75 08 01            578 	mov	_goToXY_PARM_2,#0x01
   019F 75 82 01            579 	mov	dpl,#0x01
   01A2 12 0A 99            580 	lcall	_goToXY
                            581 ;	../calc.c:213: lcd_write_string(ERR);
   01A5 85 32 82            582 	mov	dpl,_ERR
   01A8 85 33 83            583 	mov	dph,(_ERR + 1)
   01AB 85 34 F0            584 	mov	b,(_ERR + 2)
   01AE 12 0A 02            585 	lcall	_lcd_write_string
                            586 ;	../calc.c:214: calc_init();
                            587 ;	../calc.c:215: return;
   01B1 02 00 7C            588 	ljmp	_calc_init
   01B4                     589 00117$:
                            590 ;	../calc.c:218: if (key == MINUS)
   01B4 74 39               591 	mov	a,#0x39
   01B6 B5 35 2F            592 	cjne	a,_calc_key_1_28,00122$
                            593 ;	../calc.c:220: if (flag != 1)
   01B9 74 01               594 	mov	a,#0x01
   01BB B5 2E 02            595 	cjne	a,_flag,00270$
   01BE 80 0D               596 	sjmp	00119$
   01C0                     597 00270$:
                            598 ;	../calc.c:222: fuhao = MINUS;
   01C0 75 2D 39            599 	mov	_fuhao,#0x39
                            600 ;	../calc.c:223: write_data('-');
   01C3 75 82 2D            601 	mov	dpl,#0x2D
   01C6 12 09 8C            602 	lcall	_write_data
                            603 ;	../calc.c:224: flag = 1;
   01C9 75 2E 01            604 	mov	_flag,#0x01
                            605 ;	../calc.c:225: return;
   01CC 22                  606 	ret
   01CD                     607 00119$:
                            608 ;	../calc.c:229: clrscr();
   01CD 12 0A 2D            609 	lcall	_clrscr
                            610 ;	../calc.c:230: goToXY(1, 1);
   01D0 75 08 01            611 	mov	_goToXY_PARM_2,#0x01
   01D3 75 82 01            612 	mov	dpl,#0x01
   01D6 12 0A 99            613 	lcall	_goToXY
                            614 ;	../calc.c:231: lcd_write_string(ERR);
   01D9 85 32 82            615 	mov	dpl,_ERR
   01DC 85 33 83            616 	mov	dph,(_ERR + 1)
   01DF 85 34 F0            617 	mov	b,(_ERR + 2)
   01E2 12 0A 02            618 	lcall	_lcd_write_string
                            619 ;	../calc.c:232: calc_init();
                            620 ;	../calc.c:233: return;
   01E5 02 00 7C            621 	ljmp	_calc_init
   01E8                     622 00122$:
                            623 ;	../calc.c:236: if (key == MULTI)
   01E8 74 3A               624 	mov	a,#0x3A
   01EA B5 35 2F            625 	cjne	a,_calc_key_1_28,00127$
                            626 ;	../calc.c:238: if (flag != 1)
   01ED 74 01               627 	mov	a,#0x01
   01EF B5 2E 02            628 	cjne	a,_flag,00273$
   01F2 80 0D               629 	sjmp	00124$
   01F4                     630 00273$:
                            631 ;	../calc.c:240: fuhao = MULTI;
   01F4 75 2D 3A            632 	mov	_fuhao,#0x3A
                            633 ;	../calc.c:241: write_data('*');
   01F7 75 82 2A            634 	mov	dpl,#0x2A
   01FA 12 09 8C            635 	lcall	_write_data
                            636 ;	../calc.c:242: flag = 1;
   01FD 75 2E 01            637 	mov	_flag,#0x01
                            638 ;	../calc.c:243: return;
   0200 22                  639 	ret
   0201                     640 00124$:
                            641 ;	../calc.c:247: clrscr();
   0201 12 0A 2D            642 	lcall	_clrscr
                            643 ;	../calc.c:248: goToXY(1, 1);
   0204 75 08 01            644 	mov	_goToXY_PARM_2,#0x01
   0207 75 82 01            645 	mov	dpl,#0x01
   020A 12 0A 99            646 	lcall	_goToXY
                            647 ;	../calc.c:249: lcd_write_string(ERR);
   020D 85 32 82            648 	mov	dpl,_ERR
   0210 85 33 83            649 	mov	dph,(_ERR + 1)
   0213 85 34 F0            650 	mov	b,(_ERR + 2)
   0216 12 0A 02            651 	lcall	_lcd_write_string
                            652 ;	../calc.c:250: calc_init();
                            653 ;	../calc.c:251: return;
   0219 02 00 7C            654 	ljmp	_calc_init
   021C                     655 00127$:
                            656 ;	../calc.c:254: if (key == DIVID)
   021C 74 3B               657 	mov	a,#0x3B
   021E B5 35 0D            658 	cjne	a,_calc_key_1_28,00129$
                            659 ;	../calc.c:256: fuhao = DIVID;
   0221 75 2D 3B            660 	mov	_fuhao,#0x3B
                            661 ;	../calc.c:257: write_data('/');
   0224 75 82 2F            662 	mov	dpl,#0x2F
   0227 12 09 8C            663 	lcall	_write_data
                            664 ;	../calc.c:258: flag = 1;
   022A 75 2E 01            665 	mov	_flag,#0x01
                            666 ;	../calc.c:259: return;
   022D 22                  667 	ret
   022E                     668 00129$:
                            669 ;	../calc.c:261: if (key == EQUAL)
   022E 74 3C               670 	mov	a,#0x3C
   0230 B5 35 02            671 	cjne	a,_calc_key_1_28,00276$
   0233 80 03               672 	sjmp	00277$
   0235                     673 00276$:
   0235 02 06 34            674 	ljmp	00164$
   0238                     675 00277$:
                            676 ;	../calc.c:263: if (flag != 1)
   0238 74 01               677 	mov	a,#0x01
   023A B5 2E 02            678 	cjne	a,_flag,00278$
   023D 80 63               679 	sjmp	00134$
   023F                     680 00278$:
                            681 ;	../calc.c:265: goToXY(2, 15);
   023F 75 08 0F            682 	mov	_goToXY_PARM_2,#0x0F
   0242 75 82 02            683 	mov	dpl,#0x02
   0245 12 0A 99            684 	lcall	_goToXY
                            685 ;	../calc.c:266: input_cursor_left_shift();
   0248 12 0A 75            686 	lcall	_input_cursor_left_shift
                            687 ;	../calc.c:267: while (INPUTA != 0)
   024B                     688 00130$:
   024B E5 21               689 	mov	a,_INPUTA
   024D 45 22               690 	orl	a,(_INPUTA + 1)
   024F 45 23               691 	orl	a,(_INPUTA + 2)
   0251 45 24               692 	orl	a,(_INPUTA + 3)
   0253 60 47               693 	jz	00132$
                            694 ;	../calc.c:269: write_data(0x30 + INPUTA % 10);
   0255 75 09 0A            695 	mov	__modslong_PARM_2,#0x0A
   0258 E4                  696 	clr	a
   0259 F5 0A               697 	mov	(__modslong_PARM_2 + 1),a
   025B F5 0B               698 	mov	(__modslong_PARM_2 + 2),a
   025D F5 0C               699 	mov	(__modslong_PARM_2 + 3),a
   025F 85 21 82            700 	mov	dpl,_INPUTA
   0262 85 22 83            701 	mov	dph,(_INPUTA + 1)
   0265 85 23 F0            702 	mov	b,(_INPUTA + 2)
   0268 E5 24               703 	mov	a,(_INPUTA + 3)
   026A 12 0D FF            704 	lcall	__modslong
   026D AB 82               705 	mov	r3,dpl
   026F 74 30               706 	mov	a,#0x30
   0271 2B                  707 	add	a,r3
   0272 F5 82               708 	mov	dpl,a
   0274 12 09 8C            709 	lcall	_write_data
                            710 ;	../calc.c:270: INPUTA /= 10;
   0277 75 09 0A            711 	mov	__divslong_PARM_2,#0x0A
   027A E4                  712 	clr	a
   027B F5 0A               713 	mov	(__divslong_PARM_2 + 1),a
   027D F5 0B               714 	mov	(__divslong_PARM_2 + 2),a
   027F F5 0C               715 	mov	(__divslong_PARM_2 + 3),a
   0281 85 21 82            716 	mov	dpl,_INPUTA
   0284 85 22 83            717 	mov	dph,(_INPUTA + 1)
   0287 85 23 F0            718 	mov	b,(_INPUTA + 2)
   028A E5 24               719 	mov	a,(_INPUTA + 3)
   028C 12 0E 4E            720 	lcall	__divslong
   028F 85 82 21            721 	mov	_INPUTA,dpl
   0292 85 83 22            722 	mov	(_INPUTA + 1),dph
   0295 85 F0 23            723 	mov	(_INPUTA + 2),b
   0298 F5 24               724 	mov	(_INPUTA + 3),a
   029A 80 AF               725 	sjmp	00130$
   029C                     726 00132$:
                            727 ;	../calc.c:272: write_data('=');
   029C 75 82 3D            728 	mov	dpl,#0x3D
   029F 12 09 8C            729 	lcall	_write_data
   02A2                     730 00134$:
                            731 ;	../calc.c:274: switch (fuhao)
   02A2 74 38               732 	mov	a,#0x38
   02A4 B5 2D 02            733 	cjne	a,_fuhao,00280$
   02A7 80 1B               734 	sjmp	00135$
   02A9                     735 00280$:
   02A9 74 39               736 	mov	a,#0x39
   02AB B5 2D 03            737 	cjne	a,_fuhao,00281$
   02AE 02 03 4E            738 	ljmp	00139$
   02B1                     739 00281$:
   02B1 74 3A               740 	mov	a,#0x3A
   02B3 B5 2D 03            741 	cjne	a,_fuhao,00282$
   02B6 02 04 3A            742 	ljmp	00148$
   02B9                     743 00282$:
   02B9 74 3B               744 	mov	a,#0x3B
   02BB B5 2D 03            745 	cjne	a,_fuhao,00283$
   02BE 02 04 D1            746 	ljmp	00152$
   02C1                     747 00283$:
   02C1 02 06 30            748 	ljmp	00162$
                            749 ;	../calc.c:276: case PLUS:
   02C4                     750 00135$:
                            751 ;	../calc.c:277: input_cursor_left_shift();
   02C4 12 0A 75            752 	lcall	_input_cursor_left_shift
                            753 ;	../calc.c:278: goToXY(2, 15);
   02C7 75 08 0F            754 	mov	_goToXY_PARM_2,#0x0F
   02CA 75 82 02            755 	mov	dpl,#0x02
   02CD 12 0A 99            756 	lcall	_goToXY
                            757 ;	../calc.c:279: RESULT = INPUTA + INPUTB;
   02D0 E5 25               758 	mov	a,_INPUTB
   02D2 25 21               759 	add	a,_INPUTA
   02D4 F5 29               760 	mov	_RESULT,a
   02D6 E5 26               761 	mov	a,(_INPUTB + 1)
   02D8 35 22               762 	addc	a,(_INPUTA + 1)
   02DA F5 2A               763 	mov	(_RESULT + 1),a
   02DC E5 27               764 	mov	a,(_INPUTB + 2)
   02DE 35 23               765 	addc	a,(_INPUTA + 2)
   02E0 F5 2B               766 	mov	(_RESULT + 2),a
   02E2 E5 28               767 	mov	a,(_INPUTB + 3)
   02E4 35 24               768 	addc	a,(_INPUTA + 3)
   02E6 F5 2C               769 	mov	(_RESULT + 3),a
                            770 ;	../calc.c:281: while (RESULT != 0)
   02E8                     771 00136$:
   02E8 E5 29               772 	mov	a,_RESULT
   02EA 45 2A               773 	orl	a,(_RESULT + 1)
   02EC 45 2B               774 	orl	a,(_RESULT + 2)
   02EE 45 2C               775 	orl	a,(_RESULT + 3)
   02F0 60 47               776 	jz	00138$
                            777 ;	../calc.c:284: write_data(0x30 + RESULT % 10);
   02F2 75 09 0A            778 	mov	__modslong_PARM_2,#0x0A
   02F5 E4                  779 	clr	a
   02F6 F5 0A               780 	mov	(__modslong_PARM_2 + 1),a
   02F8 F5 0B               781 	mov	(__modslong_PARM_2 + 2),a
   02FA F5 0C               782 	mov	(__modslong_PARM_2 + 3),a
   02FC 85 29 82            783 	mov	dpl,_RESULT
   02FF 85 2A 83            784 	mov	dph,(_RESULT + 1)
   0302 85 2B F0            785 	mov	b,(_RESULT + 2)
   0305 E5 2C               786 	mov	a,(_RESULT + 3)
   0307 12 0D FF            787 	lcall	__modslong
   030A AB 82               788 	mov	r3,dpl
   030C 74 30               789 	mov	a,#0x30
   030E 2B                  790 	add	a,r3
   030F F5 82               791 	mov	dpl,a
   0311 12 09 8C            792 	lcall	_write_data
                            793 ;	../calc.c:285: RESULT /= 10;
   0314 75 09 0A            794 	mov	__divslong_PARM_2,#0x0A
   0317 E4                  795 	clr	a
   0318 F5 0A               796 	mov	(__divslong_PARM_2 + 1),a
   031A F5 0B               797 	mov	(__divslong_PARM_2 + 2),a
   031C F5 0C               798 	mov	(__divslong_PARM_2 + 3),a
   031E 85 29 82            799 	mov	dpl,_RESULT
   0321 85 2A 83            800 	mov	dph,(_RESULT + 1)
   0324 85 2B F0            801 	mov	b,(_RESULT + 2)
   0327 E5 2C               802 	mov	a,(_RESULT + 3)
   0329 12 0E 4E            803 	lcall	__divslong
   032C 85 82 29            804 	mov	_RESULT,dpl
   032F 85 83 2A            805 	mov	(_RESULT + 1),dph
   0332 85 F0 2B            806 	mov	(_RESULT + 2),b
   0335 F5 2C               807 	mov	(_RESULT + 3),a
   0337 80 AF               808 	sjmp	00136$
   0339                     809 00138$:
                            810 ;	../calc.c:287: write_data('=');
   0339 75 82 3D            811 	mov	dpl,#0x3D
   033C 12 09 8C            812 	lcall	_write_data
                            813 ;	../calc.c:288: calc_init();
   033F 12 00 7C            814 	lcall	_calc_init
                            815 ;	../calc.c:289: goToXY(1, 1);
   0342 75 08 01            816 	mov	_goToXY_PARM_2,#0x01
   0345 75 82 01            817 	mov	dpl,#0x01
   0348 12 0A 99            818 	lcall	_goToXY
                            819 ;	../calc.c:290: break;
   034B 02 06 30            820 	ljmp	00162$
                            821 ;	../calc.c:291: case MINUS:
   034E                     822 00139$:
                            823 ;	../calc.c:293: if ((INPUTA - INPUTB) > 0)
   034E E5 21               824 	mov	a,_INPUTA
   0350 C3                  825 	clr	c
   0351 95 25               826 	subb	a,_INPUTB
   0353 FB                  827 	mov	r3,a
   0354 E5 22               828 	mov	a,(_INPUTA + 1)
   0356 95 26               829 	subb	a,(_INPUTB + 1)
   0358 FC                  830 	mov	r4,a
   0359 E5 23               831 	mov	a,(_INPUTA + 2)
   035B 95 27               832 	subb	a,(_INPUTB + 2)
   035D FD                  833 	mov	r5,a
   035E E5 24               834 	mov	a,(_INPUTA + 3)
   0360 95 28               835 	subb	a,(_INPUTB + 3)
   0362 FE                  836 	mov	r6,a
   0363 C3                  837 	clr	c
   0364 E4                  838 	clr	a
   0365 9B                  839 	subb	a,r3
   0366 E4                  840 	clr	a
   0367 9C                  841 	subb	a,r4
   0368 E4                  842 	clr	a
   0369 9D                  843 	subb	a,r5
   036A E4                  844 	clr	a
   036B 64 80               845 	xrl	a,#0x80
   036D 8E F0               846 	mov	b,r6
   036F 63 F0 80            847 	xrl	b,#0x80
   0372 95 F0               848 	subb	a,b
   0374 50 1B               849 	jnc	00141$
                            850 ;	../calc.c:294: RESULT = INPUTA - INPUTB;
   0376 E5 21               851 	mov	a,_INPUTA
   0378 C3                  852 	clr	c
   0379 95 25               853 	subb	a,_INPUTB
   037B F5 29               854 	mov	_RESULT,a
   037D E5 22               855 	mov	a,(_INPUTA + 1)
   037F 95 26               856 	subb	a,(_INPUTB + 1)
   0381 F5 2A               857 	mov	(_RESULT + 1),a
   0383 E5 23               858 	mov	a,(_INPUTA + 2)
   0385 95 27               859 	subb	a,(_INPUTB + 2)
   0387 F5 2B               860 	mov	(_RESULT + 2),a
   0389 E5 24               861 	mov	a,(_INPUTA + 3)
   038B 95 28               862 	subb	a,(_INPUTB + 3)
   038D F5 2C               863 	mov	(_RESULT + 3),a
   038F 80 19               864 	sjmp	00142$
   0391                     865 00141$:
                            866 ;	../calc.c:296: RESULT = INPUTB - INPUTA;
   0391 E5 25               867 	mov	a,_INPUTB
   0393 C3                  868 	clr	c
   0394 95 21               869 	subb	a,_INPUTA
   0396 F5 29               870 	mov	_RESULT,a
   0398 E5 26               871 	mov	a,(_INPUTB + 1)
   039A 95 22               872 	subb	a,(_INPUTA + 1)
   039C F5 2A               873 	mov	(_RESULT + 1),a
   039E E5 27               874 	mov	a,(_INPUTB + 2)
   03A0 95 23               875 	subb	a,(_INPUTA + 2)
   03A2 F5 2B               876 	mov	(_RESULT + 2),a
   03A4 E5 28               877 	mov	a,(_INPUTB + 3)
   03A6 95 24               878 	subb	a,(_INPUTA + 3)
   03A8 F5 2C               879 	mov	(_RESULT + 3),a
   03AA                     880 00142$:
                            881 ;	../calc.c:298: input_cursor_left_shift();
   03AA 12 0A 75            882 	lcall	_input_cursor_left_shift
                            883 ;	../calc.c:299: goToXY(2, 15);
   03AD 75 08 0F            884 	mov	_goToXY_PARM_2,#0x0F
   03B0 75 82 02            885 	mov	dpl,#0x02
   03B3 12 0A 99            886 	lcall	_goToXY
                            887 ;	../calc.c:300: while (RESULT != 0)
   03B6                     888 00143$:
   03B6 E5 29               889 	mov	a,_RESULT
   03B8 45 2A               890 	orl	a,(_RESULT + 1)
   03BA 45 2B               891 	orl	a,(_RESULT + 2)
   03BC 45 2C               892 	orl	a,(_RESULT + 3)
   03BE 60 47               893 	jz	00145$
                            894 ;	../calc.c:303: write_data(0x30 + RESULT % 10);
   03C0 75 09 0A            895 	mov	__modslong_PARM_2,#0x0A
   03C3 E4                  896 	clr	a
   03C4 F5 0A               897 	mov	(__modslong_PARM_2 + 1),a
   03C6 F5 0B               898 	mov	(__modslong_PARM_2 + 2),a
   03C8 F5 0C               899 	mov	(__modslong_PARM_2 + 3),a
   03CA 85 29 82            900 	mov	dpl,_RESULT
   03CD 85 2A 83            901 	mov	dph,(_RESULT + 1)
   03D0 85 2B F0            902 	mov	b,(_RESULT + 2)
   03D3 E5 2C               903 	mov	a,(_RESULT + 3)
   03D5 12 0D FF            904 	lcall	__modslong
   03D8 AB 82               905 	mov	r3,dpl
   03DA 74 30               906 	mov	a,#0x30
   03DC 2B                  907 	add	a,r3
   03DD F5 82               908 	mov	dpl,a
   03DF 12 09 8C            909 	lcall	_write_data
                            910 ;	../calc.c:304: RESULT /= 10;
   03E2 75 09 0A            911 	mov	__divslong_PARM_2,#0x0A
   03E5 E4                  912 	clr	a
   03E6 F5 0A               913 	mov	(__divslong_PARM_2 + 1),a
   03E8 F5 0B               914 	mov	(__divslong_PARM_2 + 2),a
   03EA F5 0C               915 	mov	(__divslong_PARM_2 + 3),a
   03EC 85 29 82            916 	mov	dpl,_RESULT
   03EF 85 2A 83            917 	mov	dph,(_RESULT + 1)
   03F2 85 2B F0            918 	mov	b,(_RESULT + 2)
   03F5 E5 2C               919 	mov	a,(_RESULT + 3)
   03F7 12 0E 4E            920 	lcall	__divslong
   03FA 85 82 29            921 	mov	_RESULT,dpl
   03FD 85 83 2A            922 	mov	(_RESULT + 1),dph
   0400 85 F0 2B            923 	mov	(_RESULT + 2),b
   0403 F5 2C               924 	mov	(_RESULT + 3),a
   0405 80 AF               925 	sjmp	00143$
   0407                     926 00145$:
                            927 ;	../calc.c:306: if ((INPUTA - INPUTB) < 0)
   0407 E5 21               928 	mov	a,_INPUTA
   0409 C3                  929 	clr	c
   040A 95 25               930 	subb	a,_INPUTB
   040C FB                  931 	mov	r3,a
   040D E5 22               932 	mov	a,(_INPUTA + 1)
   040F 95 26               933 	subb	a,(_INPUTB + 1)
   0411 FC                  934 	mov	r4,a
   0412 E5 23               935 	mov	a,(_INPUTA + 2)
   0414 95 27               936 	subb	a,(_INPUTB + 2)
   0416 FD                  937 	mov	r5,a
   0417 E5 24               938 	mov	a,(_INPUTA + 3)
   0419 95 28               939 	subb	a,(_INPUTB + 3)
   041B FE                  940 	mov	r6,a
   041C 30 E7 06            941 	jnb	acc.7,00147$
                            942 ;	../calc.c:307: write_data('-');
   041F 75 82 2D            943 	mov	dpl,#0x2D
   0422 12 09 8C            944 	lcall	_write_data
   0425                     945 00147$:
                            946 ;	../calc.c:308: write_data('=');
   0425 75 82 3D            947 	mov	dpl,#0x3D
   0428 12 09 8C            948 	lcall	_write_data
                            949 ;	../calc.c:309: calc_init();
   042B 12 00 7C            950 	lcall	_calc_init
                            951 ;	../calc.c:310: goToXY(1, 1);
   042E 75 08 01            952 	mov	_goToXY_PARM_2,#0x01
   0431 75 82 01            953 	mov	dpl,#0x01
   0434 12 0A 99            954 	lcall	_goToXY
                            955 ;	../calc.c:311: break;
   0437 02 06 30            956 	ljmp	00162$
                            957 ;	../calc.c:312: case MULTI:
   043A                     958 00148$:
                            959 ;	../calc.c:313: RESULT = INPUTA * INPUTB;
   043A 85 25 09            960 	mov	__mullong_PARM_2,_INPUTB
   043D 85 26 0A            961 	mov	(__mullong_PARM_2 + 1),(_INPUTB + 1)
   0440 85 27 0B            962 	mov	(__mullong_PARM_2 + 2),(_INPUTB + 2)
   0443 85 28 0C            963 	mov	(__mullong_PARM_2 + 3),(_INPUTB + 3)
   0446 85 21 82            964 	mov	dpl,_INPUTA
   0449 85 22 83            965 	mov	dph,(_INPUTA + 1)
   044C 85 23 F0            966 	mov	b,(_INPUTA + 2)
   044F E5 24               967 	mov	a,(_INPUTA + 3)
   0451 12 0D 91            968 	lcall	__mullong
   0454 85 82 29            969 	mov	_RESULT,dpl
   0457 85 83 2A            970 	mov	(_RESULT + 1),dph
   045A 85 F0 2B            971 	mov	(_RESULT + 2),b
   045D F5 2C               972 	mov	(_RESULT + 3),a
                            973 ;	../calc.c:314: goToXY(2, 15);
   045F 75 08 0F            974 	mov	_goToXY_PARM_2,#0x0F
   0462 75 82 02            975 	mov	dpl,#0x02
   0465 12 0A 99            976 	lcall	_goToXY
                            977 ;	../calc.c:315: input_cursor_left_shift();
   0468 12 0A 75            978 	lcall	_input_cursor_left_shift
                            979 ;	../calc.c:316: while (RESULT != 0)
   046B                     980 00149$:
   046B E5 29               981 	mov	a,_RESULT
   046D 45 2A               982 	orl	a,(_RESULT + 1)
   046F 45 2B               983 	orl	a,(_RESULT + 2)
   0471 45 2C               984 	orl	a,(_RESULT + 3)
   0473 60 47               985 	jz	00151$
                            986 ;	../calc.c:318: write_data(0x30 + RESULT % 10);
   0475 75 09 0A            987 	mov	__modslong_PARM_2,#0x0A
   0478 E4                  988 	clr	a
   0479 F5 0A               989 	mov	(__modslong_PARM_2 + 1),a
   047B F5 0B               990 	mov	(__modslong_PARM_2 + 2),a
   047D F5 0C               991 	mov	(__modslong_PARM_2 + 3),a
   047F 85 29 82            992 	mov	dpl,_RESULT
   0482 85 2A 83            993 	mov	dph,(_RESULT + 1)
   0485 85 2B F0            994 	mov	b,(_RESULT + 2)
   0488 E5 2C               995 	mov	a,(_RESULT + 3)
   048A 12 0D FF            996 	lcall	__modslong
   048D AB 82               997 	mov	r3,dpl
   048F 74 30               998 	mov	a,#0x30
   0491 2B                  999 	add	a,r3
   0492 F5 82              1000 	mov	dpl,a
   0494 12 09 8C           1001 	lcall	_write_data
                           1002 ;	../calc.c:319: RESULT /= 10;
   0497 75 09 0A           1003 	mov	__divslong_PARM_2,#0x0A
   049A E4                 1004 	clr	a
   049B F5 0A              1005 	mov	(__divslong_PARM_2 + 1),a
   049D F5 0B              1006 	mov	(__divslong_PARM_2 + 2),a
   049F F5 0C              1007 	mov	(__divslong_PARM_2 + 3),a
   04A1 85 29 82           1008 	mov	dpl,_RESULT
   04A4 85 2A 83           1009 	mov	dph,(_RESULT + 1)
   04A7 85 2B F0           1010 	mov	b,(_RESULT + 2)
   04AA E5 2C              1011 	mov	a,(_RESULT + 3)
   04AC 12 0E 4E           1012 	lcall	__divslong
   04AF 85 82 29           1013 	mov	_RESULT,dpl
   04B2 85 83 2A           1014 	mov	(_RESULT + 1),dph
   04B5 85 F0 2B           1015 	mov	(_RESULT + 2),b
   04B8 F5 2C              1016 	mov	(_RESULT + 3),a
   04BA 80 AF              1017 	sjmp	00149$
   04BC                    1018 00151$:
                           1019 ;	../calc.c:321: write_data('=');
   04BC 75 82 3D           1020 	mov	dpl,#0x3D
   04BF 12 09 8C           1021 	lcall	_write_data
                           1022 ;	../calc.c:322: calc_init();
   04C2 12 00 7C           1023 	lcall	_calc_init
                           1024 ;	../calc.c:323: goToXY(1, 1);
   04C5 75 08 01           1025 	mov	_goToXY_PARM_2,#0x01
   04C8 75 82 01           1026 	mov	dpl,#0x01
   04CB 12 0A 99           1027 	lcall	_goToXY
                           1028 ;	../calc.c:324: break;
   04CE 02 06 30           1029 	ljmp	00162$
                           1030 ;	../calc.c:325: case DIVID:
   04D1                    1031 00152$:
                           1032 ;	../calc.c:326: if (0 == INPUTB)
   04D1 E5 25              1033 	mov	a,_INPUTB
   04D3 45 26              1034 	orl	a,(_INPUTB + 1)
   04D5 45 27              1035 	orl	a,(_INPUTB + 2)
   04D7 45 28              1036 	orl	a,(_INPUTB + 3)
   04D9 70 1B              1037 	jnz	00154$
                           1038 ;	../calc.c:328: clrscr();
   04DB 12 0A 2D           1039 	lcall	_clrscr
                           1040 ;	../calc.c:329: goToXY(1, 1);
   04DE 75 08 01           1041 	mov	_goToXY_PARM_2,#0x01
   04E1 75 82 01           1042 	mov	dpl,#0x01
   04E4 12 0A 99           1043 	lcall	_goToXY
                           1044 ;	../calc.c:330: lcd_write_string(DBZ);
   04E7 85 2F 82           1045 	mov	dpl,_DBZ
   04EA 85 30 83           1046 	mov	dph,(_DBZ + 1)
   04ED 85 31 F0           1047 	mov	b,(_DBZ + 2)
   04F0 12 0A 02           1048 	lcall	_lcd_write_string
                           1049 ;	../calc.c:331: calc_init();
                           1050 ;	../calc.c:332: return;
   04F3 02 00 7C           1051 	ljmp	_calc_init
   04F6                    1052 00154$:
                           1053 ;	../calc.c:335: RESULT = (long) (((float) INPUTA / INPUTB) * 1000);
   04F6 85 21 82           1054 	mov	dpl,_INPUTA
   04F9 85 22 83           1055 	mov	dph,(_INPUTA + 1)
   04FC 85 23 F0           1056 	mov	b,(_INPUTA + 2)
   04FF E5 24              1057 	mov	a,(_INPUTA + 3)
   0501 12 0C F7           1058 	lcall	___slong2fs
   0504 85 82 36           1059 	mov	_calc_sloc0_1_0,dpl
   0507 85 83 37           1060 	mov	(_calc_sloc0_1_0 + 1),dph
   050A 85 F0 38           1061 	mov	(_calc_sloc0_1_0 + 2),b
   050D F5 39              1062 	mov	(_calc_sloc0_1_0 + 3),a
   050F 85 25 82           1063 	mov	dpl,_INPUTB
   0512 85 26 83           1064 	mov	dph,(_INPUTB + 1)
   0515 85 27 F0           1065 	mov	b,(_INPUTB + 2)
   0518 E5 28              1066 	mov	a,(_INPUTB + 3)
   051A 12 0C F7           1067 	lcall	___slong2fs
   051D A8 82              1068 	mov	r0,dpl
   051F A9 83              1069 	mov	r1,dph
   0521 AA F0              1070 	mov	r2,b
   0523 FE                 1071 	mov	r6,a
   0524 C0 00              1072 	push	ar0
   0526 C0 01              1073 	push	ar1
   0528 C0 02              1074 	push	ar2
   052A C0 06              1075 	push	ar6
   052C 85 36 82           1076 	mov	dpl,_calc_sloc0_1_0
   052F 85 37 83           1077 	mov	dph,(_calc_sloc0_1_0 + 1)
   0532 85 38 F0           1078 	mov	b,(_calc_sloc0_1_0 + 2)
   0535 E5 39              1079 	mov	a,(_calc_sloc0_1_0 + 3)
   0537 12 0E EF           1080 	lcall	___fsdiv
   053A AB 82              1081 	mov	r3,dpl
   053C AC 83              1082 	mov	r4,dph
   053E AD F0              1083 	mov	r5,b
   0540 FE                 1084 	mov	r6,a
   0541 E5 81              1085 	mov	a,sp
   0543 24 FC              1086 	add	a,#0xfc
   0545 F5 81              1087 	mov	sp,a
   0547 C0 03              1088 	push	ar3
   0549 C0 04              1089 	push	ar4
   054B C0 05              1090 	push	ar5
   054D C0 06              1091 	push	ar6
   054F 90 00 00           1092 	mov	dptr,#0x0000
   0552 75 F0 7A           1093 	mov	b,#0x7A
   0555 74 44              1094 	mov	a,#0x44
   0557 12 0B F3           1095 	lcall	___fsmul
   055A AB 82              1096 	mov	r3,dpl
   055C AC 83              1097 	mov	r4,dph
   055E AD F0              1098 	mov	r5,b
   0560 FE                 1099 	mov	r6,a
   0561 E5 81              1100 	mov	a,sp
   0563 24 FC              1101 	add	a,#0xfc
   0565 F5 81              1102 	mov	sp,a
   0567 8B 82              1103 	mov	dpl,r3
   0569 8C 83              1104 	mov	dph,r4
   056B 8D F0              1105 	mov	b,r5
   056D EE                 1106 	mov	a,r6
   056E 12 0D 24           1107 	lcall	___fs2slong
   0571 85 82 29           1108 	mov	_RESULT,dpl
   0574 85 83 2A           1109 	mov	(_RESULT + 1),dph
   0577 85 F0 2B           1110 	mov	(_RESULT + 2),b
   057A F5 2C              1111 	mov	(_RESULT + 3),a
                           1112 ;	../calc.c:337: goToXY(2, 15);
   057C 75 08 0F           1113 	mov	_goToXY_PARM_2,#0x0F
   057F 75 82 02           1114 	mov	dpl,#0x02
   0582 12 0A 99           1115 	lcall	_goToXY
                           1116 ;	../calc.c:338: input_cursor_left_shift();
   0585 12 0A 75           1117 	lcall	_input_cursor_left_shift
                           1118 ;	../calc.c:339: while (RESULT != 0)
   0588 7E 00              1119 	mov	r6,#0x00
   058A                    1120 00157$:
   058A E5 29              1121 	mov	a,_RESULT
   058C 45 2A              1122 	orl	a,(_RESULT + 1)
   058E 45 2B              1123 	orl	a,(_RESULT + 2)
   0590 45 2C              1124 	orl	a,(_RESULT + 3)
   0592 60 59              1125 	jz	00159$
                           1126 ;	../calc.c:342: write_data(0x30 + RESULT % 10);
   0594 75 09 0A           1127 	mov	__modslong_PARM_2,#0x0A
   0597 E4                 1128 	clr	a
   0598 F5 0A              1129 	mov	(__modslong_PARM_2 + 1),a
   059A F5 0B              1130 	mov	(__modslong_PARM_2 + 2),a
   059C F5 0C              1131 	mov	(__modslong_PARM_2 + 3),a
   059E 85 29 82           1132 	mov	dpl,_RESULT
   05A1 85 2A 83           1133 	mov	dph,(_RESULT + 1)
   05A4 85 2B F0           1134 	mov	b,(_RESULT + 2)
   05A7 E5 2C              1135 	mov	a,(_RESULT + 3)
   05A9 C0 06              1136 	push	ar6
   05AB 12 0D FF           1137 	lcall	__modslong
   05AE AA 82              1138 	mov	r2,dpl
   05B0 74 30              1139 	mov	a,#0x30
   05B2 2A                 1140 	add	a,r2
   05B3 F5 82              1141 	mov	dpl,a
   05B5 12 09 8C           1142 	lcall	_write_data
                           1143 ;	../calc.c:343: RESULT /= 10;
   05B8 75 09 0A           1144 	mov	__divslong_PARM_2,#0x0A
   05BB E4                 1145 	clr	a
   05BC F5 0A              1146 	mov	(__divslong_PARM_2 + 1),a
   05BE F5 0B              1147 	mov	(__divslong_PARM_2 + 2),a
   05C0 F5 0C              1148 	mov	(__divslong_PARM_2 + 3),a
   05C2 85 29 82           1149 	mov	dpl,_RESULT
   05C5 85 2A 83           1150 	mov	dph,(_RESULT + 1)
   05C8 85 2B F0           1151 	mov	b,(_RESULT + 2)
   05CB E5 2C              1152 	mov	a,(_RESULT + 3)
   05CD 12 0E 4E           1153 	lcall	__divslong
   05D0 85 82 29           1154 	mov	_RESULT,dpl
   05D3 85 83 2A           1155 	mov	(_RESULT + 1),dph
   05D6 85 F0 2B           1156 	mov	(_RESULT + 2),b
   05D9 F5 2C              1157 	mov	(_RESULT + 3),a
   05DB D0 06              1158 	pop	ar6
                           1159 ;	../calc.c:344: i++;
   05DD 0E                 1160 	inc	r6
                           1161 ;	../calc.c:345: if (3 == i)
   05DE BE 03 A9           1162 	cjne	r6,#0x03,00157$
                           1163 ;	../calc.c:346: write_data('.');
   05E1 75 82 2E           1164 	mov	dpl,#0x2E
   05E4 C0 06              1165 	push	ar6
   05E6 12 09 8C           1166 	lcall	_write_data
   05E9 D0 06              1167 	pop	ar6
   05EB 80 9D              1168 	sjmp	00157$
   05ED                    1169 00159$:
                           1170 ;	../calc.c:349: if ((INPUTA / INPUTB) <= 0)
   05ED 85 25 09           1171 	mov	__divslong_PARM_2,_INPUTB
   05F0 85 26 0A           1172 	mov	(__divslong_PARM_2 + 1),(_INPUTB + 1)
   05F3 85 27 0B           1173 	mov	(__divslong_PARM_2 + 2),(_INPUTB + 2)
   05F6 85 28 0C           1174 	mov	(__divslong_PARM_2 + 3),(_INPUTB + 3)
   05F9 85 21 82           1175 	mov	dpl,_INPUTA
   05FC 85 22 83           1176 	mov	dph,(_INPUTA + 1)
   05FF 85 23 F0           1177 	mov	b,(_INPUTA + 2)
   0602 E5 24              1178 	mov	a,(_INPUTA + 3)
   0604 12 0E 4E           1179 	lcall	__divslong
   0607 AB 82              1180 	mov	r3,dpl
   0609 AC 83              1181 	mov	r4,dph
   060B AD F0              1182 	mov	r5,b
   060D FE                 1183 	mov	r6,a
   060E C3                 1184 	clr	c
   060F E4                 1185 	clr	a
   0610 9B                 1186 	subb	a,r3
   0611 E4                 1187 	clr	a
   0612 9C                 1188 	subb	a,r4
   0613 E4                 1189 	clr	a
   0614 9D                 1190 	subb	a,r5
   0615 E4                 1191 	clr	a
   0616 64 80              1192 	xrl	a,#0x80
   0618 8E F0              1193 	mov	b,r6
   061A 63 F0 80           1194 	xrl	b,#0x80
   061D 95 F0              1195 	subb	a,b
   061F 40 06              1196 	jc	00161$
                           1197 ;	../calc.c:350: write_data('0');
   0621 75 82 30           1198 	mov	dpl,#0x30
   0624 12 09 8C           1199 	lcall	_write_data
   0627                    1200 00161$:
                           1201 ;	../calc.c:351: write_data('=');
   0627 75 82 3D           1202 	mov	dpl,#0x3D
   062A 12 09 8C           1203 	lcall	_write_data
                           1204 ;	../calc.c:352: calc_init();
   062D 12 00 7C           1205 	lcall	_calc_init
                           1206 ;	../calc.c:354: } // �ж���������ͣ���������������
   0630                    1207 00162$:
                           1208 ;	../calc.c:355: flag = 0;
   0630 75 2E 00           1209 	mov	_flag,#0x00
                           1210 ;	../calc.c:357: return;
   0633 22                 1211 	ret
   0634                    1212 00164$:
                           1213 ;	../calc.c:360: if (flag == 0)
   0634 E5 2E              1214 	mov	a,_flag
   0636 70 35              1215 	jnz	00166$
                           1216 ;	../calc.c:362: INPUTA = INPUTA * 10 + key;
   0638 85 21 09           1217 	mov	__mullong_PARM_2,_INPUTA
   063B 85 22 0A           1218 	mov	(__mullong_PARM_2 + 1),(_INPUTA + 1)
   063E 85 23 0B           1219 	mov	(__mullong_PARM_2 + 2),(_INPUTA + 2)
   0641 85 24 0C           1220 	mov	(__mullong_PARM_2 + 3),(_INPUTA + 3)
   0644 90 00 0A           1221 	mov	dptr,#(0x0A&0x00ff)
   0647 E4                 1222 	clr	a
   0648 F5 F0              1223 	mov	b,a
   064A 12 0D 91           1224 	lcall	__mullong
   064D AB 82              1225 	mov	r3,dpl
   064F AC 83              1226 	mov	r4,dph
   0651 AD F0              1227 	mov	r5,b
   0653 FE                 1228 	mov	r6,a
   0654 A9 35              1229 	mov	r1,_calc_key_1_28
   0656 E4                 1230 	clr	a
   0657 F8                 1231 	mov	r0,a
   0658 33                 1232 	rlc	a
   0659 95 E0              1233 	subb	a,acc
   065B FA                 1234 	mov	r2,a
   065C FF                 1235 	mov	r7,a
   065D E9                 1236 	mov	a,r1
   065E 2B                 1237 	add	a,r3
   065F F5 21              1238 	mov	_INPUTA,a
   0661 E8                 1239 	mov	a,r0
   0662 3C                 1240 	addc	a,r4
   0663 F5 22              1241 	mov	(_INPUTA + 1),a
   0665 EA                 1242 	mov	a,r2
   0666 3D                 1243 	addc	a,r5
   0667 F5 23              1244 	mov	(_INPUTA + 2),a
   0669 EF                 1245 	mov	a,r7
   066A 3E                 1246 	addc	a,r6
   066B F5 24              1247 	mov	(_INPUTA + 3),a
   066D                    1248 00166$:
                           1249 ;	../calc.c:364: if (1 == flag)
   066D 74 01              1250 	mov	a,#0x01
   066F B5 2E 39           1251 	cjne	a,_flag,00168$
                           1252 ;	../calc.c:366: INPUTB = INPUTB * 10 + key;
   0672 85 25 09           1253 	mov	__mullong_PARM_2,_INPUTB
   0675 85 26 0A           1254 	mov	(__mullong_PARM_2 + 1),(_INPUTB + 1)
   0678 85 27 0B           1255 	mov	(__mullong_PARM_2 + 2),(_INPUTB + 2)
   067B 85 28 0C           1256 	mov	(__mullong_PARM_2 + 3),(_INPUTB + 3)
   067E 90 00 0A           1257 	mov	dptr,#(0x0A&0x00ff)
   0681 E4                 1258 	clr	a
   0682 F5 F0              1259 	mov	b,a
   0684 12 0D 91           1260 	lcall	__mullong
   0687 AC 82              1261 	mov	r4,dpl
   0689 AD 83              1262 	mov	r5,dph
   068B AE F0              1263 	mov	r6,b
   068D FF                 1264 	mov	r7,a
   068E AA 35              1265 	mov	r2,_calc_key_1_28
   0690 7B 00              1266 	mov	r3,#0x00
   0692 8A 00              1267 	mov	ar0,r2
   0694 EB                 1268 	mov	a,r3
   0695 F9                 1269 	mov	r1,a
   0696 33                 1270 	rlc	a
   0697 95 E0              1271 	subb	a,acc
   0699 FA                 1272 	mov	r2,a
   069A FB                 1273 	mov	r3,a
   069B E8                 1274 	mov	a,r0
   069C 2C                 1275 	add	a,r4
   069D F5 25              1276 	mov	_INPUTB,a
   069F E9                 1277 	mov	a,r1
   06A0 3D                 1278 	addc	a,r5
   06A1 F5 26              1279 	mov	(_INPUTB + 1),a
   06A3 EA                 1280 	mov	a,r2
   06A4 3E                 1281 	addc	a,r6
   06A5 F5 27              1282 	mov	(_INPUTB + 2),a
   06A7 EB                 1283 	mov	a,r3
   06A8 3F                 1284 	addc	a,r7
   06A9 F5 28              1285 	mov	(_INPUTB + 3),a
   06AB                    1286 00168$:
                           1287 ;	../calc.c:369: switch (key)
   06AB E5 35              1288 	mov	a,_calc_key_1_28
   06AD 24 F6              1289 	add	a,#0xff - 0x09
   06AF 50 01              1290 	jnc	00297$
   06B1 22                 1291 	ret
   06B2                    1292 00297$:
   06B2 E5 35              1293 	mov	a,_calc_key_1_28
   06B4 75 F0 03           1294 	mov	b,#0x03
   06B7 A4                 1295 	mul	ab
   06B8 90 06 BC           1296 	mov	dptr,#00298$
   06BB 73                 1297 	jmp	@a+dptr
   06BC                    1298 00298$:
   06BC 02 06 DA           1299 	ljmp	00169$
   06BF 02 06 E0           1300 	ljmp	00170$
   06C2 02 06 E6           1301 	ljmp	00171$
   06C5 02 06 EC           1302 	ljmp	00172$
   06C8 02 06 F2           1303 	ljmp	00173$
   06CB 02 06 F8           1304 	ljmp	00174$
   06CE 02 06 FE           1305 	ljmp	00175$
   06D1 02 07 04           1306 	ljmp	00176$
   06D4 02 07 0A           1307 	ljmp	00177$
   06D7 02 07 10           1308 	ljmp	00178$
                           1309 ;	../calc.c:371: case 0:
   06DA                    1310 00169$:
                           1311 ;	../calc.c:372: write_data('0');
   06DA 75 82 30           1312 	mov	dpl,#0x30
                           1313 ;	../calc.c:373: break;
                           1314 ;	../calc.c:374: case 1:
   06DD 02 09 8C           1315 	ljmp	_write_data
   06E0                    1316 00170$:
                           1317 ;	../calc.c:375: write_data('1');
   06E0 75 82 31           1318 	mov	dpl,#0x31
                           1319 ;	../calc.c:376: break;
                           1320 ;	../calc.c:377: case 2:
   06E3 02 09 8C           1321 	ljmp	_write_data
   06E6                    1322 00171$:
                           1323 ;	../calc.c:378: write_data('2');
   06E6 75 82 32           1324 	mov	dpl,#0x32
                           1325 ;	../calc.c:379: break;
                           1326 ;	../calc.c:380: case 3:
   06E9 02 09 8C           1327 	ljmp	_write_data
   06EC                    1328 00172$:
                           1329 ;	../calc.c:381: write_data('3');
   06EC 75 82 33           1330 	mov	dpl,#0x33
                           1331 ;	../calc.c:382: break;
                           1332 ;	../calc.c:383: case 4:
   06EF 02 09 8C           1333 	ljmp	_write_data
   06F2                    1334 00173$:
                           1335 ;	../calc.c:384: write_data('4');
   06F2 75 82 34           1336 	mov	dpl,#0x34
                           1337 ;	../calc.c:385: break;
                           1338 ;	../calc.c:386: case 5:
   06F5 02 09 8C           1339 	ljmp	_write_data
   06F8                    1340 00174$:
                           1341 ;	../calc.c:387: write_data('5');
   06F8 75 82 35           1342 	mov	dpl,#0x35
                           1343 ;	../calc.c:388: break;
                           1344 ;	../calc.c:389: case 6:
   06FB 02 09 8C           1345 	ljmp	_write_data
   06FE                    1346 00175$:
                           1347 ;	../calc.c:390: write_data('6');
   06FE 75 82 36           1348 	mov	dpl,#0x36
                           1349 ;	../calc.c:391: break;
                           1350 ;	../calc.c:392: case 7:
   0701 02 09 8C           1351 	ljmp	_write_data
   0704                    1352 00176$:
                           1353 ;	../calc.c:393: write_data('7');
   0704 75 82 37           1354 	mov	dpl,#0x37
                           1355 ;	../calc.c:394: break;
                           1356 ;	../calc.c:395: case 8:
   0707 02 09 8C           1357 	ljmp	_write_data
   070A                    1358 00177$:
                           1359 ;	../calc.c:396: write_data('8');
   070A 75 82 38           1360 	mov	dpl,#0x38
                           1361 ;	../calc.c:397: break;
                           1362 ;	../calc.c:398: case 9:
   070D 02 09 8C           1363 	ljmp	_write_data
   0710                    1364 00178$:
                           1365 ;	../calc.c:399: write_data('9');
   0710 75 82 39           1366 	mov	dpl,#0x39
                           1367 ;	../calc.c:401: }
   0713 02 09 8C           1368 	ljmp	_write_data
                           1369 	.area CSEG    (CODE)
                           1370 	.area CONST   (CODE)
   1015                    1371 __str_0:
   1015 44 69 76 69 64 65  1372 	.ascii "Divided by zero!"
        64 20 62 79 20 7A
        65 72 6F 21
   1025 00                 1373 	.db 0x00
   1026                    1374 __str_1:
   1026 45 72 72 6F 72 21  1375 	.ascii "Error!"
   102C 00                 1376 	.db 0x00
                           1377 	.area XINIT   (CODE)
                           1378 	.area CABS    (ABS,CODE)
