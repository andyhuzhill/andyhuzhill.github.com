/*
 *    Filename: calc.c
 *
 * Description:
 *     Version: 1.0
 *    Compiler: sdcc
 *     Created: 2012-5-19 ����6:55:18
 *      Author: ������
 *   CopyRight: GPL v3
 *    Revision:
 *
 */
#include "calc.h"
#include "key.h"
//typedef unsigned char uchar;

long INPUTA,INPUTB,RESULT; //�������룬һ�����
unsigned char fuhao=0,flag=0;
uchar count=1;  //���������б����
uchar counter1,counter2; //λ����������
uchar table1[16];
uchar table2[16];


const char *DBZ="Divided by zero!";
const char *OF="Overflow!";
const char *ERR="Error!";

/*
 * ���ܣ���ʼ������������
 */

void calc_init(void)
{

    count = 1;
    counter1 = counter2 = 0;
    INPUTA = INPUTB = RESULT = 0;
    table1[15] = table2[15] = 0;
}



void calc(void)
{
    uchar key,i=0;
    key = scanKeyToInt();
    if (key == PLUS)
        {
            fuhao = PLUS;
            flag = 1;
            return;
        }
    if (key == MINUS)
        {
            fuhao = MINUS;
            flag = 1;
            return ;
        }
    if (key == MULTI)
        {
            fuhao = MULTI;
            flag = 1;
            return;
        }
    if (key == DIVID)
        {
            fuhao = DIVID;
            flag = 1;
            return;
        }
    if (key == EQUAL)
        {
            if (flag != 1)
                {
                    lcd_write_string("error");
                }
            switch(fuhao)
            {
                case PLUS:
                    RESULT = INPUTA + INPUTB;
                    write_com(0x80 + 0x4f);
                    write_com(0x04);
                    while(RESULT != 0)
                        {
                            write_data(0x30 + RESULT % 10);
                            RESULT /= 10;
                        }
                    write_data(0x3d);
                    INPUTA = 0;
                    INPUTB = 0;
                    flag = 0;
                    fuhao = 0;
                    break;
                case MINUS:
                    if ((INPUTA - INPUTB) >0)
                        RESULT = INPUTA - INPUTB;
                    else
                        RESULT = INPUTB - INPUTA;
                    write_com(0x80 + 0x4f);
                    write_com(0x04);
                    while(RESULT != 0)
                        {
                            write_data(0x30 + RESULT % 10);
                            RESULT /= 10;
                        }
                    if ((INPUTA - INPUTB) < 0)
                        write_data(0x2d);
                    write_data(0x3d);
                    INPUTA = 0;
                    INPUTB = 0;
                    flag = 0;
                    fuhao = 0;
                    break;
                case MULTI:
                    RESULT = INPUTA * INPUTB;
                    write_com(0x80 + 0x4f);
                    write_com(0x04);
                    while(RESULT != 0)
                        {
                            write_data(0x30 + RESULT % 10);
                            RESULT /= 10;
                        }
                    write_data(0x3d);
                    INPUTA = 0;
                    INPUTB = 0;
                    flag = 0;
                    fuhao = 0;
                    break;
                case DIVID:
                    if (0 == INPUTB)
                        {
                            clrscr();
                            write_com(0x80+0x1f);
                            write_com(0x04);
                            lcd_write_string(DBZ);
                        }

                    RESULT =(long)(((float)INPUTA / INPUTB) * 1000);
                    write_com(0x80 + 0x4f);
                    write_com(0x04);
                    while(RESULT != 0)
                        {
                            write_data(0x30 + RESULT % 10);
                            RESULT /= 10;
                            i++;
                            if (3 == i)
                                write_data(0x2e);
                        }
                    if ((INPUTA / INPUTB) <= 0)
                        write_data(0x30);
                    write_data(0x3d);
                    INPUTA = 0;
                    INPUTB = 0;
                    flag = 0;
                    fuhao = 0;
                    break;
            }
            flag = 1;
            return;
        }

    if (flag != 1)
        {
            INPUTA = INPUTA*10 + key;
        }
    if (1 == flag)
        {
            INPUTB = INPUTB*10 + key;
        }
}


